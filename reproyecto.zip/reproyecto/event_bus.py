from __future__ import annotations

import logging
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class EventBus:
    """Bus de eventos ligero para acoplamiento flojo entre componentes."""

    def __init__(self) -> None:
        self._subs: Dict[str, List[Callable[[Optional[Any]], None]]] = {}

    def subscribe(self, event: str, callback: Callable[[
                  Optional[Any]], None]) -> None:
        self._subs.setdefault(event, []).append(callback)

    def emit(self, event: str, payload: Optional[Any] = None) -> None:
        for callback in self._subs.get(event, []):
            try:
                callback(payload)
            except Exception:  # pragma: no cover - errores de listeners
                logger.exception("Listener error para el evento '%s'", event)


__all__ = ["EventBus"]
