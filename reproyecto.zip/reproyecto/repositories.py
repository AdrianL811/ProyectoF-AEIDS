from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional

from .db import MemoryCollection, MongoClient, ObjectId


class BaseRepo:
    def __init__(self, db, name: str) -> None:
        self.col = db[name]
        self._mongo_backend = MongoClient is not None and not isinstance(
            self.col, MemoryCollection)

    def all(self, filtros: Optional[Dict[str, Any]] = None):
        return list(self.col.find(filtros or {}))

    def get(self, oid: str):
        if self._mongo_backend:
            return self.col.find_one({"_id": ObjectId(oid)})
        return self.col.find_one({"_id": oid})

    def insert(self, data: Dict[str, Any]) -> str:
        payload = data.copy()
        if payload.get("_id") in (None, ""):
            payload.pop("_id", None)
        result = self.col.insert_one(payload)
        inserted = getattr(result, "inserted_id", None)
        return str(inserted)

    def update(self, oid: str, cambios: Dict[str, Any]) -> None:
        key = ObjectId(oid) if self._mongo_backend else oid
        self.col.update_one({"_id": key}, {"$set": cambios})

    def delete(self, oid: str) -> None:
        key = ObjectId(oid) if self._mongo_backend else oid
        self.col.delete_one({"_id": key})


class ProductoRepository(BaseRepo):
    def __init__(self, db) -> None:
        super().__init__(db, "productos")


class ProveedorRepository(BaseRepo):
    def __init__(self, db) -> None:
        super().__init__(db, "proveedores")


class UsuarioRepository(BaseRepo):
    def __init__(self, db) -> None:
        super().__init__(db, "usuarios")

    def get_by_user(self, user: str):
        return self.col.find_one({"usuario": user})


class PromocionRepository(BaseRepo):
    def __init__(self, db) -> None:
        super().__init__(db, "promociones")


class OrdenRepository(BaseRepo):
    def __init__(self, db) -> None:
        super().__init__(db, "ordenes_compra")


class FacturaRepository(BaseRepo):
    def __init__(self, db) -> None:
        super().__init__(db, "facturas")


class HistorialRepository:
    def __init__(self, db) -> None:
        self.hist = db["historial_cambios_stock"]
        self.ajustes = db["ajustes_stock"]
        self.recepciones = db["recepciones"]

    def log_cambio(
            self,
            pid: str,
            nombre: str,
            antes: int,
            despues: int,
            usuario: str) -> None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.hist.insert_one(
            {
                "producto_id": pid,
                "nombre": nombre,
                "cantidad_anterior": antes,
                "cantidad_nueva": despues,
                "fecha": now,
                "usuario": usuario,
            }
        )

    def log_ajuste(
            self,
            pid: str,
            nombre: str,
            tipo: str,
            cantidad: int,
            motivo: str) -> None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.ajustes.insert_one(
            {
                "producto_id": pid,
                "producto_nombre": nombre,
                "tipo_ajuste": tipo,
                "cantidad": cantidad,
                "motivo": motivo,
                "fecha": now,
            }
        )

    def log_recepcion(
            self,
            pid: str,
            nombre: str,
            proveedor: str,
            cantidad: int,
            cad: str,
            estado: str) -> None:
        self.recepciones.insert_one(
            {
                "producto_id": pid,
                "producto_nombre": nombre,
                "proveedor": proveedor,
                "cantidad": cantidad,
                "fecha_caducidad": cad,
                "estado_fisico": estado,
            }
        )


__all__ = [
    "BaseRepo",
    "ProductoRepository",
    "ProveedorRepository",
    "UsuarioRepository",
    "PromocionRepository",
    "OrdenRepository",
    "FacturaRepository",
    "HistorialRepository",
]
