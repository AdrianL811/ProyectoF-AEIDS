from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from reproyecto.gui import ctk, messagebox, tk, ttk


@dataclass
class ViewContext:
    app: "ctk.CTk"
    bus: any


class FeatureView:
    """Base para las vistas especificas de cada funcionalidad."""

    def __init__(self, context: ViewContext) -> None:
        self.context = context
        self._active: Optional[ctk.CTkToplevel] = None

    @property
    def bus(self):
        return self.context.bus

    @property
    def app(self):
        return self.context.app

    def open_window(self, title: str, size: str = "800x600") -> "ctk.CTkToplevel":
        if self._active is not None:
            try:
                self._active.destroy()
            except Exception:
                pass
        window = ctk.CTkToplevel(self.app)
        window.title(title)
        window.geometry(size)
        self._active = window
        return window


__all__ = ["FeatureView", "ViewContext", "ctk", "ttk", "messagebox", "tk"]
