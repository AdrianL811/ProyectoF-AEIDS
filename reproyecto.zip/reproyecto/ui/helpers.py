from __future__ import annotations

from typing import Iterable, List, Sequence

from reproyecto.exporters import CSVExportStrategy, ExcelExportStrategy
from reproyecto.gui import ctk, ttk


def build_table(parent, columns: Sequence[str]):
    """Crea un Treeview con scrollbar vertical."""

    cont = ctk.CTkFrame(parent)
    cont.pack(fill="both", expand=True, padx=10, pady=8)
    tree = ttk.Treeview(cont, columns=columns, show="headings")
    for col in columns:
        tree.heading(col, text=col)
        tree.column(col, width=140)
    vsb = ttk.Scrollbar(cont, orient="vertical", command=tree.yview)
    tree.configure(yscrollcommand=vsb.set)
    tree.pack(side="left", fill="both", expand=True)
    vsb.pack(side="right", fill="y")
    return tree


def clear_table(tree) -> None:
    for item in tree.get_children():
        tree.delete(item)


def populate_table(tree, rows: Iterable[Sequence[object]]) -> None:
    clear_table(tree)
    for row in rows:
        tree.insert("", "end", values=list(row))


def export_tree(tree, suggested_name: str, csv_only: bool = False) -> None:
    columns = [tree.heading(col)["text"] for col in tree["columns"]]
    rows: List[List[object]] = [tree.item(item)["values"] for item in tree.get_children()]
    if csv_only:
        CSVExportStrategy().export(columns, rows, suggested_name)
    else:
        ExcelExportStrategy().export(columns, rows, suggested_name)


__all__ = ["build_table", "clear_table", "populate_table", "export_tree"]
