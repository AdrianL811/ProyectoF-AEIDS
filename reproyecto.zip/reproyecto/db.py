from __future__ import annotations

import logging
import re
from typing import Any, Dict, Optional
from uuid import uuid4

from .config import CONFIG

try:
    from pymongo import MongoClient  # type: ignore
    from bson.objectid import ObjectId  # type: ignore
except Exception:  # pragma: no cover - fallback cuando pymongo no esta instalado
    MongoClient = None  # type: ignore

    class ObjectId:  # type: ignore
        def __init__(self, value: str) -> None:
            self._value = value

        def __str__(self) -> str:
            return self._value


logger = logging.getLogger(__name__)


class _MemInsert:
    def __init__(self, inserted_id: str) -> None:
        self.inserted_id = inserted_id


class MemoryCollection:
    def __init__(self) -> None:
        self._docs: Dict[str, Dict[str, Any]] = {}

    def find(self, query: Optional[Dict[str, Any]] = None):
        query = query or {}
        return [document.copy() for document in self._docs.values()
                if _match(document, query)]

    def find_one(self, query: Dict[str, Any]):
        for document in self._docs.values():
            if _match(document, query):
                return document.copy()
        return None

    def insert_one(self, data: Dict[str, Any]):
        new_id = str(uuid4())
        payload = data.copy()
        payload["_id"] = new_id
        self._docs[new_id] = payload
        return _MemInsert(new_id)

    def update_one(self, query: Dict[str, Any], op: Dict[str, Any]):
        document = self.find_one(query)
        if not document:
            return
        updates = op.get("$set", {})
        document.update(updates)
        self._docs[document["_id"]] = document

    def delete_one(self, query: Dict[str, Any]):
        document = self.find_one(query)
        if not document:
            return
        self._docs.pop(document["_id"], None)


class MemoryDB:
    def __init__(self, name: str = "db") -> None:
        self._cols: Dict[str, MemoryCollection] = {}
        self.name = name

    def __getitem__(self, col: str):
        if col not in self._cols:
            self._cols[col] = MemoryCollection()
        return self._cols[col]


def _match(document: Dict[str, Any], query: Dict[str, Any]) -> bool:
    for key, value in (query or {}).items():
        target = document.get(key)
        if isinstance(value, dict) and "$regex" in value:
            pattern = value["$regex"]
            options = re.I if value.get("$options") == "i" else 0
            if not re.search(pattern, str(target or ""), options):
                return False
        elif isinstance(value, dict) and "$or" in value:
            if not any(_match(document, sub) for sub in value["$or"]):
                return False
        elif isinstance(value, dict) and "$lt" in value:
            if not (target or 0) < value["$lt"]:
                return False
        elif isinstance(value, dict) and "$gte" in value and "$lte" in value:
            target_value = str(target or "")
            if not (value["$gte"] <= target_value <= value["$lte"]):
                return False
        else:
            if target != value:
                return False
    return True


class MongoProvider:
    """Expone una unica instancia de acceso a la base MongoDB o a su respaldo en memoria."""

    _instance: Optional["MongoProvider"] = None

    def __new__(cls) -> "MongoProvider":
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance.client = None  # type: ignore[attr-defined]
            cls._instance.db = MemoryDB(CONFIG.db_name)
            cls._instance._initialise_connection()
        return cls._instance

    def _initialise_connection(self) -> None:
        if not MongoClient:
            logger.info("pymongo no disponible; se utilizara MemoryDB.")
            self.client = None  # type: ignore[attr-defined]
            self.db = MemoryDB(CONFIG.db_name)
            return

        uri = CONFIG.mongo_uri
        timeout_ms = CONFIG.mongo_timeout_ms
        db_name = CONFIG.db_name

        try:
            client = MongoClient(uri, serverSelectionTimeoutMS=timeout_ms)
            client.admin.command("ping")
        except Exception as exc:  # pragma: no cover - depende del entorno
            logger.warning(
                "No fue posible conectar a MongoDB: %s. Se usara MemoryDB.", exc)
            self.client = None  # type: ignore[attr-defined]
            self.db = MemoryDB(db_name)
        else:
            self.client = client  # type: ignore[attr-defined]
            self.db = client[db_name]
            logger.info("Conectado a MongoDB '%s'", db_name)

    @property
    def db(self):  # type: ignore[override]
        return self._db

    @db.setter
    def db(self, value):  # type: ignore[override]
        self._db = value


__all__ = [
    "MongoProvider",
    "MongoClient",
    "ObjectId",
    "MemoryDB",
    "MemoryCollection",
]
