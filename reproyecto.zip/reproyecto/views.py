from __future__ import annotations

from typing import Callable, Dict, List, Optional

from .config import logger
from .gui import GUI_AVAILABLE, ctk, messagebox
from .services.container import ServiceContainer
from .ui.base_view import ViewContext

from .features.alerts.controller import AlertsController
from .features.alerts.view import AlertsView
from .features.assign_product_supplier.controller import AssignProductSupplierController
from .features.assign_product_supplier.view import AssignProductSupplierView
from .features.generate_invoice.controller import GenerateInvoiceController
from .features.generate_invoice.view import GenerateInvoiceView
from .features.inventory.controller import InventoryController
from .features.inventory.view import InventoryView
from .features.invoice_lookup.controller import InvoiceLookupController
from .features.invoice_lookup.view import InvoiceLookupView
from .features.login.controller import LoginController
from .features.login.view import LoginView
from .features.manage_products.controller import ManageProductsController
from .features.manage_products.view import ManageProductsView
from .features.manage_promotions.controller import ManagePromotionsController
from .features.manage_promotions.view import ManagePromotionsView
from .features.manage_providers.controller import ManageProvidersController
from .features.manage_providers.view import ManageProvidersView
from .features.manage_users.controller import ManageUsersController
from .features.manage_users.view import ManageUsersView
from .features.provider_orders.controller import ProviderOrdersController
from .features.provider_orders.view import ProviderOrdersView
from .features.purchase_orders.controller import PurchaseOrdersController
from .features.purchase_orders.view import PurchaseOrdersView
from .features.receptions.controller import ReceptionController
from .features.receptions.view import ReceptionView
from .features.register_product.controller import RegisterProductController
from .features.register_product.view import RegisterProductView
from .features.register_user.controller import RegistrationController
from .features.register_user.view import RegistrationView
from .features.sales_orders.controller import SalesOrdersController
from .features.sales_orders.view import SalesOrdersView
from .features.stock_adjustments.controller import StockAdjustmentController
from .features.stock_adjustments.view import StockAdjustmentView
from .features.support.controller import SupportController
from .features.support.view import SupportView
from .features.update_product_supplier.controller import UpdateProductSupplierController
from .features.update_product_supplier.view import UpdateProductSupplierView


class MainView:
    def __init__(self, services: ServiceContainer) -> None:
        if not GUI_AVAILABLE:
            logger.warning("GUI no disponible. Usa --selftest para validar la logica del dominio.")

        self.services = services
        self.bus = services.bus

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("green")
        self.app = ctk.CTk()
        self.app.geometry("800x600")
        self.app.title("Sistema de Inventario")

        self.context = ViewContext(app=self.app, bus=self.bus)
        self._menu_window: Optional[ctk.CTkToplevel] = None

        self._build_controllers()
        self._build_views()

        ctk.CTkLabel(self.app, text="Sistema de Inventario", font=("Arial", 24)).pack(pady=30)
        ctk.CTkButton(self.app, text="Iniciar Sesion", command=self._open_login).pack(pady=10)
        ctk.CTkButton(self.app, text="Registrar Cuenta", command=self._open_registration).pack(pady=10)

        self.bus.subscribe("auth:login", self._on_login)
        self.bus.subscribe("auth:logout", self._on_logout)

    def _build_controllers(self) -> None:
        self.login_controller = LoginController(self.services)
        self.registration_controller = RegistrationController(self.services)
        self.manage_products_controller = ManageProductsController(self.services)
        self.register_product_controller = RegisterProductController(self.services)
        self.manage_providers_controller = ManageProvidersController(self.services)
        self.manage_users_controller = ManageUsersController(self.services)
        self.assign_supplier_controller = AssignProductSupplierController(self.services)
        self.update_supplier_controller = UpdateProductSupplierController(self.services)
        self.manage_promotions_controller = ManagePromotionsController(self.services)
        self.reception_controller = ReceptionController(self.services)
        self.stock_adjustment_controller = StockAdjustmentController(self.services)
        self.sales_orders_controller = SalesOrdersController(self.services)
        self.purchase_orders_controller = PurchaseOrdersController(self.services)
        self.provider_orders_controller = ProviderOrdersController(self.services)
        self.generate_invoice_controller = GenerateInvoiceController(self.services)
        self.invoice_lookup_controller = InvoiceLookupController(self.services)
        self.alerts_controller = AlertsController(self.services)
        self.inventory_controller = InventoryController(self.services)
        self.support_controller = SupportController(self.services)

    def _build_views(self) -> None:
        self.login_view = LoginView(self.context, self.login_controller)
        self.registration_view = RegistrationView(self.context, self.registration_controller)

        def register_view_factory() -> RegisterProductView:
            return RegisterProductView(self.context, self.register_product_controller)

        self.manage_products_view = ManageProductsView(
            self.context, self.manage_products_controller, register_view_factory
        )
        self.manage_providers_view = ManageProvidersView(self.context, self.manage_providers_controller)
        self.manage_users_view = ManageUsersView(self.context, self.manage_users_controller)
        self.assign_supplier_view_factory = lambda: AssignProductSupplierView(
            self.context, self.assign_supplier_controller
        )
        self.update_supplier_view_factory = lambda: UpdateProductSupplierView(
            self.context, self.update_supplier_controller
        )
        self.manage_promotions_view = ManagePromotionsView(self.context, self.manage_promotions_controller)
        self.reception_view = ReceptionView(self.context, self.reception_controller)
        self.stock_adjustment_view = StockAdjustmentView(self.context, self.stock_adjustment_controller)
        self.sales_orders_view = SalesOrdersView(self.context, self.sales_orders_controller)
        self.purchase_orders_view = PurchaseOrdersView(self.context, self.purchase_orders_controller)
        self.provider_orders_view = ProviderOrdersView(self.context, self.provider_orders_controller)
        self.generate_invoice_view = GenerateInvoiceView(self.context, self.generate_invoice_controller)
        self.invoice_lookup_view = InvoiceLookupView(self.context, self.invoice_lookup_controller)
        self.alerts_view = AlertsView(self.context, self.alerts_controller)
        self.inventory_view = InventoryView(self.context, self.inventory_controller)
        self.support_view = SupportView(self.context, self.support_controller)

    def run(self) -> None:
        self.app.mainloop()

    # ---- acciones principales ----
    def _open_login(self) -> None:
        self.login_view.show()

    def _open_registration(self) -> None:
        self.registration_view.show()

    def _open_assign_supplier(self) -> None:
        self.assign_supplier_view_factory().show()

    def _open_update_supplier(self) -> None:
        self.update_supplier_view_factory().show()

    def _on_login(self, payload: Dict[str, object]) -> None:
        usuario = payload.get("usuario", {})
        rol = getattr(usuario, "get", lambda *_: "encargado")("rol", "encargado")
        self._open_menu(str(rol))

    def _on_logout(self, _payload: Optional[dict]) -> None:
        if self._menu_window is not None:
            try:
                self._menu_window.destroy()
            except Exception:
                pass
            self._menu_window = None

    def _open_menu(self, rol: str) -> None:
        if self._menu_window is not None:
            try:
                self._menu_window.destroy()
            except Exception:
                pass

        menu = ctk.CTkToplevel(self.app)
        menu.geometry("800x600")
        menu.title(f"Menu - {rol.capitalize()}")
        self._menu_window = menu

        ctk.CTkLabel(menu, text=f"Bienvenido, rol: {rol}", font=("Arial", 18)).pack(pady=20)

        acciones = self._acciones_por_rol(rol)
        if not acciones:
            ctk.CTkLabel(menu, text="Rol sin opciones configuradas").pack(pady=10)
        for texto, callback in acciones:
            ctk.CTkButton(menu, text=texto, command=callback).pack(pady=6)

        ctk.CTkButton(menu, text="Soporte", command=self.support_view.show).pack(pady=14)
        ctk.CTkButton(menu, text="Cerrar Sesion", command=self.login_controller.logout).pack(pady=20)

    def _acciones_por_rol(self, rol: str) -> List[tuple[str, Callable[[], None]]]:
        proveedor_nombre = self._current_provider_name()

        acciones_admin: List[tuple[str, Callable[[], None]]] = [
            ("Gestionar Productos", self.manage_products_view.show),
            ("Gestionar Proveedores", self.manage_providers_view.show),
            ("Gestionar Usuarios", self.manage_users_view.show),
            ("Asignar Proveedor a Producto", self._open_assign_supplier),
            ("Actualizar Proveedor de Producto", self._open_update_supplier),
            ("Promociones", self.manage_promotions_view.show),
            ("Recepciones", self.reception_view.show),
            ("Ajustes de Stock", self.stock_adjustment_view.show),
            ("Ordenes / Facturas (Venta)", self.sales_orders_view.show),
            ("Crear Orden de Compra", self.purchase_orders_view.show),
            ("Consultar Facturas", lambda: self.invoice_lookup_view.show(False)),
            ("Alertas", self.alerts_view.show),
            ("Consultar Inventario", self.inventory_view.show),
        ]

        acciones_gerente = [
            ("Consultar Inventario", self.inventory_view.show),
            ("Registrar Producto", self.manage_products_view.show),
            ("Crear Orden de Compra", self.purchase_orders_view.show),
            ("Recepciones", self.reception_view.show),
            ("Ajustes de Stock", self.stock_adjustment_view.show),
            ("Ordenes / Facturas (Venta)", self.sales_orders_view.show),
            ("Consultar Facturas", lambda: self.invoice_lookup_view.show(False)),
            ("Alertas", self.alerts_view.show),
        ]

        acciones_encargado = [
            ("Registrar Recepcion", self.reception_view.show),
            ("Actualizar Stock", self.stock_adjustment_view.show),
            ("Consultar Inventario", self.inventory_view.show),
        ]

        acciones_proveedor: List[tuple[str, Callable[[], None]]] = []
        if proveedor_nombre:
            acciones_proveedor = [
                ("Ver Ordenes de Compra", lambda: self.provider_orders_view.show(proveedor_nombre)),
                ("Generar Factura", lambda: self.generate_invoice_view.show(proveedor_nombre)),
                ("Consultar Facturas", lambda: self.invoice_lookup_view.show(True)),
            ]
        else:
            acciones_proveedor = [(
                "Completa tu perfil",
                lambda: messagebox.showwarning(
                    "Proveedor", "El usuario no tiene un nombre asociado en el sistema."
                ),
            )]

        mapping: Dict[str, List[tuple[str, Callable[[], None]]]] = {
            "administrador": acciones_admin,
            "gerente": acciones_gerente,
            "encargado": acciones_encargado,
            "proveedor": acciones_proveedor,
        }
        return mapping.get(rol, [])

    def _current_provider_name(self) -> Optional[str]:
        current = self.services.auth.current_user()
        if not current:
            return None
        return current.get("nombre") or current.get("usuario")


__all__ = ["MainView"]
