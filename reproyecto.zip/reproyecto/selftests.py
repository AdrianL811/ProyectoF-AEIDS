from __future__ import annotations

from datetime import date, timedelta

from .config import logger
from .event_bus import EventBus
from .controller import InventarioController
from .exporters import CSVExportStrategy
from .models import Producto, Promocion, Proveedor, Usuario


class TestFailure(Exception):
    ...


def assert_eq(a, b, msg=""):
    if a != b:
        raise TestFailure(msg or f"{a}!={b}")


def run_selftests():
    logger.info("Iniciando self-tests...")
    bus = EventBus()
    c = InventarioController(bus)
    if not c.usuarios.get_by_user("admin"):
        c.registrar_usuario(
            Usuario(
                "admin",
                "admin",
                "administrador",
                "Admin"))
    assert_eq(c.login("admin", "admin"), True, "login admin")

    prov_id = c.crear_proveedor(Proveedor("ProvA", "Emp", "555", "a@a.com"))
    prod_id = c.crear_producto(
        Producto(
            "Manzana",
            "Verde",
            "Fruta",
            10,
            10.0,
            "ProvA",
            "2026-01-01"))

    c.ajustar_stock(prod_id, -2, "merma")
    prod = c.productos.get(prod_id)
    assert_eq(int(prod.get("cantidad")), 8, "ajuste -2")

    hoy = date.today().strftime("%Y-%m-%d")
    fin = (date.today() + timedelta(days=7)).strftime("%Y-%m-%d")
    c.crear_promo(Promocion(prod_id, 20, hoy, fin, True))
    price = c.precio_con_promo(c.productos.get(prod_id))
    assert_eq(price, 8.0, "precio con 20%")

    venta_items = [{"producto_id": prod_id, "cantidad": 2}]
    orden_venta = c.crear_orden("Mostrador", venta_items)
    prod = c.productos.get(prod_id)
    assert_eq(int(prod.get("cantidad")), 6, "stock tras orden")
    doc_venta = c.ordenes.get(orden_venta)
    assert_eq(round(float(doc_venta.get("total")), 2), 16.0, "total orden")
    factura_venta = c.crear_factura(
        orden_venta, [{"producto": "Manzana", "cantidad": 2, "precio_unitario": 8.0}])
    doc_factura_venta = c.facturas.get(factura_venta)
    assert_eq(
        round(
            float(
                doc_factura_venta.get("precio_total")),
            2),
        16.0,
        "factura venta total")
    doc_venta_final = c.ordenes.get(orden_venta)
    assert_eq(doc_venta_final.get("facturada"), True, "orden venta facturada")

    compra_id = c.crear_orden_compra(
        "ProvA", [{"producto_id": prod_id, "cantidad": 5}], "2026-02-01")
    doc_compra = c.ordenes.get(compra_id)
    assert_eq(doc_compra.get("tipo"), "compra", "tipo compra")
    assert_eq(doc_compra.get("estado"), "pendiente", "estado pendiente")
    c.actualizar_orden(compra_id, {"estado": "confirmada"})
    doc_compra_conf = c.ordenes.get(compra_id)
    assert_eq(doc_compra_conf.get("estado"), "confirmada", "estado confirmada")
    factura_compra = c.crear_factura(
        compra_id, [{"producto": "Manzana", "cantidad": 5, "precio_unitario": 9.5}])
    doc_factura_compra = c.facturas.get(factura_compra)
    assert_eq(
        round(
            float(
                doc_factura_compra.get("precio_total")),
            2),
        47.5,
        "factura compra total")
    doc_compra_final = c.ordenes.get(compra_id)
    assert_eq(doc_compra_final.get("facturada"),
              True, "orden compra facturada")
    ordenes_prov = c.ordenes_por_proveedor("ProvA")
    assert_eq(any(str(o.get("_id")) == str(compra_id)
              for o in ordenes_prov), True, "orden proveedor listada")
    facturas_prov = c.listar_facturas({"proveedor": "ProvA"})
    assert_eq(any(str(f.get("_id")) == str(factura_compra)
              for f in facturas_prov), True, "factura proveedor listada")

    cols = ["A", "B"]
    rows = [[1, 2], [3, 4]]
    CSVExportStrategy().export(cols, rows, "selftest.xlsx")
    logger.info("Self-tests completados correctamente.")
