from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ReceptionData:
    producto_id: str
    cantidad: int
    proveedor: str
    caducidad: str
    estado: str


__all__ = ["ReceptionData"]
