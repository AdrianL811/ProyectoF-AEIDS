from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .controller import ReceptionController
from .model import ReceptionData


class ReceptionView(FeatureView):
    def __init__(self, context, controller: ReceptionController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Recepcion de Productos", "820x640")
        ctk.CTkLabel(window, text="Registrar Recepcion", font=("Arial", 18)).pack(pady=10)

        frame = ctk.CTkFrame(window)
        frame.pack(pady=12)

        productos = self.controller.products()
        opciones_productos = [f"{p.get('nombre', '')} | {p.get('_id')}" for p in productos]
        ctk.CTkLabel(frame, text="Producto").pack(pady=4)
        combo_producto = ctk.CTkComboBox(frame, values=opciones_productos or [""])
        if opciones_productos:
            combo_producto.set(opciones_productos[0])
        combo_producto.pack(pady=4)

        proveedores = [p.get("nombre", "") for p in self.controller.providers() if p.get("nombre")]
        ctk.CTkLabel(frame, text="Proveedor").pack(pady=4)
        combo_proveedor = ctk.CTkComboBox(frame, values=proveedores or [""])
        if proveedores:
            combo_proveedor.set(proveedores[0])
        combo_proveedor.pack(pady=4)

        entry_cantidad = ctk.CTkEntry(frame, placeholder_text="Cantidad")
        entry_cantidad.pack(pady=4)
        entry_caducidad = ctk.CTkEntry(frame, placeholder_text="Fecha caducidad (YYYY-MM-DD)")
        entry_caducidad.pack(pady=4)
        entry_estado = ctk.CTkEntry(frame, placeholder_text="Estado fisico")
        entry_estado.pack(pady=4)

        def registrar() -> None:
            try:
                seleccionado = combo_producto.get()
                producto_id = seleccionado.split("|")[-1].strip()
                data = ReceptionData(
                    producto_id=producto_id,
                    cantidad=int(entry_cantidad.get().strip()),
                    proveedor=combo_proveedor.get().strip(),
                    caducidad=entry_caducidad.get().strip() or "",
                    estado=entry_estado.get().strip() or "bueno",
                )
            except Exception:
                messagebox.showerror("Recepcion", "Datos invalidos")
                return
            if not data.proveedor:
                messagebox.showwarning("Recepcion", "Selecciona un proveedor")
                return
            self.controller.register(data)
            messagebox.showinfo("Recepcion", "Recepcion registrada")
            entry_cantidad.delete(0, "end")
            entry_caducidad.delete(0, "end")
            entry_estado.delete(0, "end")
            load_historial()

        ctk.CTkButton(window, text="Guardar recepcion", command=registrar).pack(pady=10)

        ctk.CTkLabel(window, text="Historial de recepciones", font=("Arial", 16)).pack(pady=10)
        columns = ("Producto", "Proveedor", "Cantidad", "Caducidad", "Estado")
        tree = build_table(window, columns)

        def load_historial() -> None:
            registros = self.controller.history()
            rows = [
                [
                    reg.get("producto_nombre", ""),
                    reg.get("proveedor", ""),
                    reg.get("cantidad", 0),
                    reg.get("fecha_caducidad", ""),
                    reg.get("estado_fisico", ""),
                ]
                for reg in registros
            ]
            populate_table(tree, rows)

        load_historial()


__all__ = ["ReceptionView"]
