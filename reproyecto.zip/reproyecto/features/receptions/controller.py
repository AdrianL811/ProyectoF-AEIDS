from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..base import FeatureController
from .model import ReceptionData


@dataclass
class ReceptionController(FeatureController):
    """Coordina el registro de recepciones de mercancia."""

    def products(self) -> List[Dict[str, Any]]:
        return self.services.products.list()

    def providers(self) -> List[Dict[str, Any]]:
        return self.services.providers.list()

    def register(self, data: ReceptionData) -> None:
        usuario = self._current_user_name()
        self.services.stock.reception(
            data.producto_id,
            data.cantidad,
            data.proveedor,
            data.caducidad,
            data.estado,
            usuario,
        )

    def history(self) -> List[Dict[str, Any]]:
        # Acceso directo al repositorio para mostrar el historial en la interfaz.
        return list(self.services.stock.historial.recepciones.find())

    def _current_user_name(self) -> Optional[str]:
        current = self.services.auth.current_user()
        if not current:
            return None
        return current.get("nombre") or current.get("usuario")


__all__ = ["ReceptionController"]
