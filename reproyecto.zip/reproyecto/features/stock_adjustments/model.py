from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class StockAdjustmentData:
    producto_id: str
    delta: int
    motivo: str


__all__ = ["StockAdjustmentData"]
