from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .controller import StockAdjustmentController
from .model import StockAdjustmentData


class StockAdjustmentView(FeatureView):
    def __init__(self, context, controller: StockAdjustmentController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Ajustes de Stock", "780x640")
        ctk.CTkLabel(window, text="Actualizar Stock", font=("Arial", 18)).pack(pady=10)

        productos = self.controller.products()
        opciones = [f"{p.get('nombre', '')} | {p.get('_id')}" for p in productos]
        combo_producto = ctk.CTkComboBox(window, values=opciones or [""])
        if opciones:
            combo_producto.set(opciones[0])
        combo_producto.pack(pady=6)

        entry_delta = ctk.CTkEntry(window, placeholder_text="Delta (+ entrada / - salida)")
        entry_delta.pack(pady=6)
        entry_motivo = ctk.CTkEntry(window, placeholder_text="Motivo")
        entry_motivo.pack(pady=6)

        def aplicar() -> None:
            try:
                seleccion = combo_producto.get()
                producto_id = seleccion.split("|")[-1].strip()
                data = StockAdjustmentData(
                    producto_id=producto_id,
                    delta=int(entry_delta.get().strip()),
                    motivo=entry_motivo.get().strip() or "ajuste",
                )
            except Exception:
                messagebox.showerror("Ajuste", "Datos invalidos")
                return
            self.controller.adjust(data)
            messagebox.showinfo("Ajuste", "Stock actualizado")
            entry_delta.delete(0, "end")
            entry_motivo.delete(0, "end")
            load_historial()

        ctk.CTkButton(window, text="Aplicar ajuste", command=aplicar).pack(pady=10)

        ctk.CTkLabel(window, text="Historial de ajustes", font=("Arial", 16)).pack(pady=10)
        columns = ("Producto", "Tipo", "Cantidad", "Motivo", "Fecha")
        tree = build_table(window, columns)

        def load_historial() -> None:
            ajustes = self.controller.history()
            rows = [
                [
                    reg.get("producto_nombre", ""),
                    reg.get("tipo_ajuste", ""),
                    reg.get("cantidad", 0),
                    reg.get("motivo", ""),
                    reg.get("fecha", ""),
                ]
                for reg in ajustes
            ]
            populate_table(tree, rows)

        load_historial()


__all__ = ["StockAdjustmentView"]
