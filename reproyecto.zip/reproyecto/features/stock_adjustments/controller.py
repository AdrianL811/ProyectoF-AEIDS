from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..base import FeatureController
from .model import StockAdjustmentData


@dataclass
class StockAdjustmentController(FeatureController):
    """Permite incrementar o disminuir existencias."""

    def products(self) -> List[Dict[str, Any]]:
        return self.services.products.list()

    def adjust(self, data: StockAdjustmentData) -> None:
        usuario = self._current_user_name()
        self.services.stock.adjust(data.producto_id, data.delta, data.motivo, usuario)

    def history(self) -> List[Dict[str, Any]]:
        return list(self.services.stock.historial.ajustes.find())

    def _current_user_name(self) -> Optional[str]:
        current = self.services.auth.current_user()
        if not current:
            return None
        return current.get("nombre") or current.get("usuario")


__all__ = ["StockAdjustmentController"]
