from __future__ import annotations

from typing import Dict, List

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .controller import ManageUsersController
from .model import UserFormData


class ManageUsersView(FeatureView):
    def __init__(self, context, controller: ManageUsersController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Gestion de Usuarios")
        columns = ("ID", "Usuario", "Nombre", "Rol")
        tree = build_table(window, columns)

        form = ctk.CTkFrame(window)
        form.pack(fill="x", padx=10, pady=8)
        entry_usuario = ctk.CTkEntry(form, placeholder_text="Usuario")
        entry_usuario.pack(side="left", padx=4)
        entry_nombre = ctk.CTkEntry(form, placeholder_text="Nombre")
        entry_nombre.pack(side="left", padx=4)
        entry_password = ctk.CTkEntry(form, placeholder_text="Contrasena", show="*")
        entry_password.pack(side="left", padx=4)
        combo_roles = ctk.CTkComboBox(form, values=self.controller.available_roles())
        combo_roles.set("encargado")
        combo_roles.pack(side="left", padx=4)

        def limpiar() -> None:
            entry_usuario.delete(0, "end")
            entry_nombre.delete(0, "end")
            entry_password.delete(0, "end")
            combo_roles.set("encargado")

        def load() -> None:
            usuarios = self.controller.list()
            rows: List[List[object]] = []
            for usr in usuarios:
                rows.append(
                    [
                        str(usr.get("_id")),
                        usr.get("usuario", ""),
                        usr.get("nombre", ""),
                        usr.get("rol", ""),
                    ]
                )
            populate_table(tree, rows)

        def agregar() -> None:
            data = UserFormData(
                usuario=entry_usuario.get().strip(),
                password=entry_password.get().strip(),
                rol=combo_roles.get().strip(),
                nombre=entry_nombre.get().strip(),
            )
            if not data.usuario or not data.password:
                messagebox.showwarning("Usuarios", "Usuario y contrasena son obligatorios")
                return
            self.controller.create(data)
            limpiar()
            load()

        def editar() -> None:
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Usuarios", "Selecciona un registro")
                return
            oid = str(tree.item(sel[0])["values"][0])
            usuario = self.controller.get(oid)
            editor = ctk.CTkToplevel(window)
            editor.geometry("420x360")
            editor.title("Editar Usuario")
            entradas: Dict[str, ctk.CTkEntry] = {}
            for campo in ("usuario", "nombre", "password"):
                ctk.CTkLabel(editor, text=campo.capitalize()).pack(pady=4)
                entry = ctk.CTkEntry(editor)
                entry.insert(0, usuario.get(campo, ""))
                entry.pack(pady=4)
                entradas[campo] = entry
            ctk.CTkLabel(editor, text="Rol").pack(pady=4)
            combo = ctk.CTkComboBox(editor, values=self.controller.available_roles())
            combo.set(usuario.get("rol", "encargado"))
            combo.pack(pady=4)

            def guardar() -> None:
                data = UserFormData(
                    usuario=entradas["usuario"].get().strip(),
                    password=entradas["password"].get().strip(),
                    rol=combo.get().strip(),
                    nombre=entradas["nombre"].get().strip(),
                )
                if not data.usuario or not data.password:
                    messagebox.showwarning("Usuarios", "Usuario y contrasena son obligatorios")
                    return
                self.controller.update(oid, data)
                editor.destroy()
                load()

            ctk.CTkButton(editor, text="Guardar", command=guardar).pack(pady=12)

        def eliminar() -> None:
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Usuarios", "Selecciona un registro")
                return
            oid = str(tree.item(sel[0])["values"][0])
            if messagebox.askyesno("Usuarios", "Eliminar el usuario seleccionado?"):
                self.controller.delete(oid)
                load()

        acciones = ctk.CTkFrame(window)
        acciones.pack(fill="x", padx=10, pady=6)
        ctk.CTkButton(acciones, text="Agregar", command=agregar).pack(side="left", padx=4)
        ctk.CTkButton(acciones, text="Editar", command=editar).pack(side="left", padx=4)
        ctk.CTkButton(acciones, text="Eliminar", command=eliminar).pack(side="left", padx=4)
        ctk.CTkButton(acciones, text="Limpiar", command=limpiar).pack(side="left", padx=4)

        self.bus.subscribe("usuarios:cambio", lambda _=None: load())
        load()


__all__ = ["ManageUsersView"]
