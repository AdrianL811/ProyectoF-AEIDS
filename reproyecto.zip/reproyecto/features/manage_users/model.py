from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class UserFormData:
    usuario: str
    password: str
    rol: str
    nombre: str


__all__ = ["UserFormData"]
