from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from reproyecto.constants import ROLES_DISPONIBLES

from ..base import FeatureController
from ..usuarios.model import Usuario
from .model import UserFormData


@dataclass
class ManageUsersController(FeatureController):
    """Define la logica para administrar usuarios desde la GUI."""

    def list(self) -> List[Dict[str, Any]]:
        return self.services.users.list()

    def create(self, data: UserFormData) -> str:
        usuario = Usuario(
            usuario=data.usuario,
            password=data.password,
            rol=data.rol,
            nombre=data.nombre,
        )
        return self.services.users.create(usuario)

    def update(self, oid: str, data: UserFormData) -> None:
        cambios = {
            "usuario": data.usuario,
            "password": data.password,
            "rol": data.rol,
            "nombre": data.nombre,
        }
        self.services.users.update(oid, cambios)

    def delete(self, oid: str) -> None:
        self.services.users.delete(oid)

    def get(self, oid: str) -> Dict[str, Any]:
        return self.services.users.get(oid)

    def available_roles(self) -> List[str]:
        return ROLES_DISPONIBLES.copy()


__all__ = ["ManageUsersController"]
