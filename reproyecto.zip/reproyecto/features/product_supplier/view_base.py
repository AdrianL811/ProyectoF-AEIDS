from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .base import ProductSupplierBaseController


class ProductSupplierView(FeatureView):
    def __init__(
        self,
        context,
        controller: ProductSupplierBaseController,
        title: str,
        success_message: str,
    ) -> None:
        super().__init__(context)
        self.controller = controller
        self.title = title
        self.success_message = success_message

    def show(self) -> None:
        window = self.open_window(self.title, "820x560")
        ctk.CTkLabel(window, text=self.title, font=("Arial", 18)).pack(pady=10)
        columns = ("ID", "Nombre", "Marca", "Categoria", "Cantidad", "Proveedor")
        tree = build_table(window, columns)

        def load() -> None:
            seleccionado = tree.focus()
            products = self.controller.products()
            rows = [
                [
                    str(prod.get("_id")),
                    prod.get("nombre", ""),
                    prod.get("marca", ""),
                    prod.get("categoria", ""),
                    int(prod.get("cantidad", 0)),
                    prod.get("proveedor", "Sin asignar"),
                ]
                for prod in products
            ]
            populate_table(tree, rows)
            items = tree.get_children()
            if seleccionado and seleccionado in items:
                tree.focus(seleccionado)
                tree.selection_set(seleccionado)
            elif items:
                tree.focus(items[0])

        combo = ctk.CTkComboBox(window, values=[""])
        combo.pack(pady=8)

        def refresh_providers() -> None:
            providers = [p.get("nombre", "").strip() for p in self.controller.providers()]
            providers = [nombre for nombre in providers if nombre]
            combo.configure(values=providers or [""])
            if providers:
                if combo.get().strip() not in providers:
                    combo.set(providers[0])
            else:
                combo.set("")

        def aplicar() -> None:
            seleccion = tree.selection()
            if not seleccion:
                foco = tree.focus()
                if foco:
                    seleccion = (foco,)
            if not seleccion:
                messagebox.showwarning("Proveedor", "Selecciona un producto")
                return
            proveedor = combo.get().strip()
            if not proveedor:
                messagebox.showwarning("Proveedor", "Selecciona un proveedor")
                return
            producto_id = str(tree.item(seleccion[0])["values"][0])
            self.controller.set_supplier(producto_id, proveedor)
            messagebox.showinfo("Proveedor", self.success_message)
            load()

        ctk.CTkButton(window, text="Guardar", command=aplicar).pack(pady=10)
        ctk.CTkButton(window, text="Cerrar", command=window.destroy).pack(pady=5)

        self.bus.subscribe("proveedores:cambio", lambda _=None: refresh_providers())
        self.bus.subscribe("productos:cambio", lambda _=None: load())
        refresh_providers()
        load()


__all__ = ["ProductSupplierView"]
