from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from ..base import FeatureController


@dataclass
class ProductSupplierBaseController(FeatureController):
    """Funcionalidad compartida para asignar proveedores a productos."""

    def products(self) -> List[Dict[str, Any]]:
        return self.services.products.list()

    def providers(self) -> List[Dict[str, Any]]:
        return self.services.providers.list()

    def set_supplier(self, producto_id: str, proveedor: str) -> None:
        self.services.products.update(producto_id, {"proveedor": proveedor})


__all__ = ["ProductSupplierBaseController"]
