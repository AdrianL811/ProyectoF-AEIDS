from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk
from reproyecto.ui.helpers import build_table, export_tree, populate_table

from .controller import InventoryController
from .model import InventoryFilters


class InventoryView(FeatureView):
    def __init__(self, context, controller: InventoryController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Consulta de Inventario", "950x650")
        ctk.CTkLabel(window, text="Consulta de Inventario", font=("Arial", 18)).pack(pady=10)

        filtros_frame = ctk.CTkFrame(window)
        filtros_frame.pack(pady=10)
        entry_nombre = ctk.CTkEntry(filtros_frame, placeholder_text="Nombre")
        entry_nombre.pack(side="left", padx=5)
        entry_categoria = ctk.CTkEntry(filtros_frame, placeholder_text="Categoria")
        entry_categoria.pack(side="left", padx=5)
        entry_proveedor = ctk.CTkEntry(filtros_frame, placeholder_text="Proveedor")
        entry_proveedor.pack(side="left", padx=5)

        columns = ("Nombre", "Marca", "Categoria", "Cantidad", "Precio", "Caducidad", "Proveedor")
        tree = build_table(window, columns)

        def load_general() -> None:
            filtros = InventoryFilters(
                nombre=entry_nombre.get().strip(),
                categoria=entry_categoria.get().strip(),
                proveedor=entry_proveedor.get().strip(),
            )
            productos = self.controller.filter(filtros)
            populate_table(
                tree,
                [
                    [
                        prod.get("nombre", ""),
                        prod.get("marca", ""),
                        prod.get("categoria", ""),
                        int(prod.get("cantidad", 0)),
                        float(prod.get("precio", 0.0)),
                        prod.get("fecha_caducidad", "N/A"),
                        prod.get("proveedor", ""),
                    ]
                    for prod in productos
                ],
            )

        def limpiar() -> None:
            entry_nombre.delete(0, "end")
            entry_categoria.delete(0, "end")
            entry_proveedor.delete(0, "end")
            load_general()

        def stock_bajo() -> None:
            productos = self.controller.low_stock()
            populate_table(
                tree,
                [
                    [
                        prod.get("nombre", ""),
                        prod.get("marca", ""),
                        prod.get("categoria", ""),
                        int(prod.get("cantidad", 0)),
                        float(prod.get("precio", 0.0)),
                        prod.get("fecha_caducidad", "N/A"),
                        prod.get("proveedor", ""),
                    ]
                    for prod in productos
                ],
            )

        def proximos() -> None:
            productos = self.controller.expiring()
            populate_table(
                tree,
                [
                    [
                        prod.get("nombre", ""),
                        prod.get("marca", ""),
                        prod.get("categoria", ""),
                        int(prod.get("cantidad", 0)),
                        float(prod.get("precio", 0.0)),
                        prod.get("fecha_caducidad", "N/A"),
                        prod.get("proveedor", ""),
                    ]
                    for prod in productos
                ],
            )

        ctk.CTkButton(filtros_frame, text="Buscar", command=load_general).pack(side="left", padx=5)
        ctk.CTkButton(filtros_frame, text="Limpiar", command=limpiar).pack(side="left", padx=5)
        ctk.CTkButton(filtros_frame, text="Stock bajo", command=stock_bajo).pack(side="left", padx=5)
        ctk.CTkButton(filtros_frame, text="Proximos a caducar", command=proximos).pack(side="left", padx=5)

        ctk.CTkButton(window, text="Exportar Excel", command=lambda: export_tree(tree, "inventario.xlsx")).pack(pady=6)
        ctk.CTkButton(
            window,
            text="Exportar CSV",
            command=lambda: export_tree(tree, "inventario.xlsx", csv_only=True),
        ).pack(pady=3)

        load_general()


__all__ = ["InventoryView"]
