from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any, Dict, List

from ..base import FeatureController
from .model import InventoryFilters


@dataclass
class InventoryController(FeatureController):
    """Consulta de productos con distintos criterios."""

    def filter(self, filtros: InventoryFilters) -> List[Dict[str, Any]]:
        query = filtros.as_query()
        return self.services.products.list(query if query else None)

    def low_stock(self, threshold: int = 10) -> List[Dict[str, Any]]:
        return self.services.products.list({"cantidad": {"$lt": threshold}})

    def expiring(self, days: int = 15) -> List[Dict[str, Any]]:
        hoy = datetime.now()
        limite = hoy + timedelta(days=days)
        query = {
            "fecha_caducidad": {
                "$gte": hoy.strftime("%Y-%m-%d"),
                "$lte": limite.strftime("%Y-%m-%d"),
            }
        }
        return self.services.products.list(query)


__all__ = ["InventoryController"]
