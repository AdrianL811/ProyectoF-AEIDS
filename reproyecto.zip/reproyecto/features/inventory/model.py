from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass(slots=True)
class InventoryFilters:
    nombre: str = ""
    categoria: str = ""
    proveedor: str = ""

    def as_query(self) -> Dict[str, object]:
        filtros: Dict[str, object] = {}
        if self.nombre:
            filtros["nombre"] = {"$regex": self.nombre, "$options": "i"}
        if self.categoria:
            filtros["categoria"] = {"$regex": self.categoria, "$options": "i"}
        if self.proveedor:
            filtros["proveedor"] = {"$regex": self.proveedor, "$options": "i"}
        return filtros


__all__ = ["InventoryFilters"]
