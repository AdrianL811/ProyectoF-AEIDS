from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(slots=True)
class InvoiceFilters:
    proveedor: Optional[str] = None

    def as_query(self) -> dict:
        query = {}
        if self.proveedor:
            query["proveedor"] = self.proveedor
        return query


__all__ = ["InvoiceFilters"]
