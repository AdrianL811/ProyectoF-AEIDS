from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .controller import InvoiceLookupController
from .model import InvoiceFilters


class InvoiceLookupView(FeatureView):
    def __init__(self, context, controller: InvoiceLookupController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self, solo_propias: bool = False) -> None:
        provider = self.controller.current_provider() if solo_propias else None
        if solo_propias and not provider:
            messagebox.showwarning("Facturas", "El usuario actual no tiene un nombre asociado")
            return

        window = self.open_window("Consulta de Facturas", "900x620")
        ctk.CTkLabel(window, text="Facturas", font=("Arial", 18)).pack(pady=10)

        columns = ("Orden", "Proveedor", "Total", "Fecha", "Productos")
        tree = build_table(window, columns)

        filtros = InvoiceFilters(proveedor=provider)

        def load() -> None:
            facturas = self.controller.list(filtros)
            rows = []
            for factura in facturas:
                productos = ", ".join(
                    [
                        f"{p.get('producto', '')} x{p.get('cantidad', 0)} = {p.get('subtotal', 0):.2f}"
                        for p in factura.get("productos", [])
                    ]
                )
                rows.append(
                    [
                        factura.get("orden_id", ""),
                        factura.get("proveedor", ""),
                        factura.get("precio_total", 0),
                        factura.get("fecha_emision", ""),
                        productos,
                    ]
                )
            populate_table(tree, rows)

        ctk.CTkButton(window, text="Actualizar", command=load).pack(pady=8)
        self.bus.subscribe("facturas:cambio", lambda _=None: load())
        load()


__all__ = ["InvoiceLookupView"]
