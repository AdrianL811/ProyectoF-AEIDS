from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..base import FeatureController
from .model import InvoiceFilters


@dataclass
class InvoiceLookupController(FeatureController):
    """Consulta facturas con o sin filtrado por proveedor."""

    def list(self, filtros: InvoiceFilters) -> List[Dict[str, Any]]:
        query = filtros.as_query()
        return self.services.invoices.list(query if query else None)

    def current_provider(self) -> Optional[str]:
        current = self.services.auth.current_user()
        if not current:
            return None
        return current.get("nombre") or current.get("usuario")


__all__ = ["InvoiceLookupController"]
