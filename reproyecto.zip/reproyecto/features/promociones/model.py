from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(slots=True)
class Promocion:
    """Promocion aplicada a un producto durante un periodo."""

    producto_id: str
    descuento: int
    inicio: str
    fin: str
    activa: bool = True
    _id: Optional[str] = None


__all__ = ["Promocion"]
