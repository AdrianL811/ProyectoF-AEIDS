from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk

from .controller import SupportController


class SupportView(FeatureView):
    def __init__(self, context, controller: SupportController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = ctk.CTkToplevel(self.app)
        window.geometry("400x300")
        window.title("Soporte Tecnico")
        info = self.controller.info()
        ctk.CTkLabel(window, text="Soporte Tecnico", font=("Arial", 20)).pack(pady=20)
        ctk.CTkLabel(window, text=f"Nombre: {info.nombre}", font=("Arial", 14)).pack(pady=5)
        ctk.CTkLabel(window, text=f"Correo: {info.correo}", font=("Arial", 14)).pack(pady=5)
        ctk.CTkLabel(window, text=f"Telefono: {info.telefono}", font=("Arial", 14)).pack(pady=5)


__all__ = ["SupportView"]
