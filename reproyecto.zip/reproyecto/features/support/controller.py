from __future__ import annotations

from dataclasses import dataclass

from reproyecto.constants import SUPPORT_CONTACT

from ..base import FeatureController
from .model import SupportInfo


@dataclass
class SupportController(FeatureController):
    """Expone la informacion de soporte tecnico."""

    def info(self) -> SupportInfo:
        return SupportInfo(
            nombre=SUPPORT_CONTACT["nombre"],
            correo=SUPPORT_CONTACT["correo"],
            telefono=SUPPORT_CONTACT["telefono"],
        )


__all__ = ["SupportController"]
