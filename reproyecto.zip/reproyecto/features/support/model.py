from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SupportInfo:
    nombre: str
    correo: str
    telefono: str


__all__ = ["SupportInfo"]
