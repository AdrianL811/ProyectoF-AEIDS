from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(slots=True)
class Usuario:
    """Entidad de usuario autorizada para operar el sistema."""

    usuario: str
    password: str
    rol: str
    nombre: str = ""
    _id: Optional[str] = None


__all__ = ["Usuario"]
