from __future__ import annotations

from dataclasses import dataclass

from reproyecto.services.container import ServiceContainer


@dataclass
class FeatureController:
    """Controlador base con acceso al contenedor de servicios."""

    services: ServiceContainer


__all__ = ["FeatureController"]
