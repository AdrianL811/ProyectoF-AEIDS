from __future__ import annotations

from dataclasses import dataclass

from ..product_supplier.base import ProductSupplierBaseController
from .model import ProductSupplierSelection


@dataclass
class AssignProductSupplierController(ProductSupplierBaseController):
    """Asigna un proveedor a un producto que no lo tiene definido."""

    def assign(self, data: ProductSupplierSelection) -> None:
        self.set_supplier(data.producto_id, data.proveedor)


__all__ = ["AssignProductSupplierController"]
