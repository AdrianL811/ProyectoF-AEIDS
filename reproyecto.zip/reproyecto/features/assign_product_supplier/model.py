from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ProductSupplierSelection:
    producto_id: str
    proveedor: str


__all__ = ["ProductSupplierSelection"]
