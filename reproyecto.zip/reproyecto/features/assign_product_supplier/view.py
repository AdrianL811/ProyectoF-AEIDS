from __future__ import annotations

from reproyecto.features.product_supplier.view_base import ProductSupplierView

from .controller import AssignProductSupplierController


class AssignProductSupplierView(ProductSupplierView):
    def __init__(self, context, controller: AssignProductSupplierController) -> None:
        super().__init__(
            context,
            controller,
            "Asignar Proveedor a Producto",
            "Proveedor asignado correctamente",
        )


__all__ = ["AssignProductSupplierView"]
