from __future__ import annotations

from dataclasses import dataclass
from typing import List

from reproyecto.constants import ROLES_DISPONIBLES

from ..base import FeatureController
from ..usuarios.model import Usuario
from .model import RegistrationData


@dataclass
class RegistrationController(FeatureController):
    """Gestiona el registro inicial de usuarios desde la pantalla principal."""

    def available_roles(self) -> List[str]:
        return ROLES_DISPONIBLES.copy()

    def register(self, data: RegistrationData) -> str:
        usuario = Usuario(
            usuario=data.usuario,
            password=data.password,
            rol=data.rol,
            nombre=data.nombre,
        )
        return self.services.users.create(usuario)


__all__ = ["RegistrationController"]
