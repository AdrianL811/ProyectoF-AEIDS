from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from .controller import RegistrationController
from .model import RegistrationData


class RegistrationView(FeatureView):
    def __init__(self, context, controller: RegistrationController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = ctk.CTkToplevel(self.app)
        window.geometry("420x520")
        window.title("Registrar Usuario")

        ctk.CTkLabel(window, text="Nuevo Usuario", font=("Arial", 20)).pack(pady=10)
        entry_name = ctk.CTkEntry(window, placeholder_text="Nombre completo")
        entry_name.pack(pady=5)
        entry_user = ctk.CTkEntry(window, placeholder_text="Usuario")
        entry_user.pack(pady=5)
        entry_pass = ctk.CTkEntry(window, placeholder_text="Contrasena", show="*")
        entry_pass.pack(pady=5)

        ctk.CTkLabel(window, text="Rol").pack(pady=5)
        combo_roles = ctk.CTkComboBox(window, values=self.controller.available_roles())
        combo_roles.set("encargado")
        combo_roles.pack(pady=5)

        def guardar() -> None:
            datos = RegistrationData(
                nombre=entry_name.get().strip(),
                usuario=entry_user.get().strip(),
                password=entry_pass.get().strip(),
                rol=combo_roles.get().strip(),
            )
            if not datos.nombre or not datos.usuario or not datos.password:
                messagebox.showwarning("Registro", "Completa todos los campos")
                return
            self.controller.register(datos)
            messagebox.showinfo("Registro", "Usuario registrado")
            window.destroy()

        ctk.CTkButton(window, text="Registrar", command=guardar).pack(pady=20)


__all__ = ["RegistrationView"]
