from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class RegistrationData:
    nombre: str
    usuario: str
    password: str
    rol: str


__all__ = ["RegistrationData"]
