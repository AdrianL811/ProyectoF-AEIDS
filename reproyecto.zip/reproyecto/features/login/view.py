from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from .controller import LoginController
from .model import LoginCredentials


class LoginView(FeatureView):
    def __init__(self, context, controller: LoginController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = ctk.CTkToplevel(self.app)
        window.geometry("400x300")
        window.title("Iniciar Sesion")

        ctk.CTkLabel(window, text="Iniciar Sesion", font=("Arial", 20)).pack(pady=20)
        entry_user = ctk.CTkEntry(window, placeholder_text="Usuario")
        entry_user.pack(pady=10)
        entry_pass = ctk.CTkEntry(window, placeholder_text="Contrasena", show="*")
        entry_pass.pack(pady=10)

        def attempt_login() -> None:
            usuario = entry_user.get().strip()
            password = entry_pass.get().strip()
            if not usuario or not password:
                messagebox.showwarning("Sesion", "Ingresa usuario y contrasena")
                return
            if self.controller.authenticate(LoginCredentials(usuario, password)):
                window.destroy()
            else:
                messagebox.showerror("Sesion", "Usuario o contrasena incorrectos")

        ctk.CTkButton(window, text="Ingresar", command=attempt_login).pack(pady=20)


__all__ = ["LoginView"]
