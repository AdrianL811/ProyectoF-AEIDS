from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class LoginCredentials:
    usuario: str
    password: str


__all__ = ["LoginCredentials"]
