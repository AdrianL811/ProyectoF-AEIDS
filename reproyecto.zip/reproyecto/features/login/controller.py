from __future__ import annotations

from dataclasses import dataclass

from ..base import FeatureController
from .model import LoginCredentials


@dataclass
class LoginController(FeatureController):
    """Coordinador de autenticacion para la vista de inicio de sesion."""

    def authenticate(self, credentials: LoginCredentials) -> bool:
        return self.services.auth.login(credentials.usuario, credentials.password)

    def logout(self) -> None:
        self.services.auth.logout()


__all__ = ["LoginController"]
