from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .controller import ProviderOrdersController
from .model import (
    ProviderOrderConfirmation,
    ProviderOrderItemUpdate,
    ProviderOrdersFilter,
)


class ProviderOrdersView(FeatureView):
    def __init__(self, context, controller: ProviderOrdersController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self, proveedor: str) -> None:
        window = self.open_window("Ordenes de Compra", "860x600")
        ctk.CTkLabel(window, text=f"Ordenes para {proveedor}", font=("Arial", 18)).pack(pady=10)

        columns = ("ID", "Proveedor", "Fecha", "Entrega", "Estado", "Productos")
        tree = build_table(window, columns)

        def load() -> None:
            filtro = ProviderOrdersFilter(proveedor=proveedor)
            ordenes = self.controller.find(filtro)
            rows = []
            for orden in ordenes:
                productos = ", ".join(
                    [
                        f"{itm.get('nombre', '')} "
                        f"(solicitado {itm.get('cantidad', 0)}, "
                        f"confirmado {itm.get('cantidad_confirmada', '-')})"
                        for itm in orden.get("items", [])
                    ]
                )
                rows.append(
                    [
                        str(orden.get("_id")),
                        orden.get("proveedor_o_cliente", ""),
                        orden.get("fecha", ""),
                        orden.get("fecha_entrega", ""),
                        orden.get("estado", ""),
                        productos,
                    ]
                )
            populate_table(tree, rows)

        def confirmar() -> None:
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Ordenes", "Selecciona una orden")
                return
            oid = str(tree.item(sel[0])["values"][0])
            orden = self.controller.get(oid)

            editor = ctk.CTkToplevel(window)
            editor.geometry("520x540")
            editor.title("Confirmar orden de compra")

            ctk.CTkLabel(
                editor,
                text=f"Orden {oid}",
                font=("Arial", 16),
            ).pack(pady=8)

            ctk.CTkLabel(editor, text="Fecha entrega (opcional)").pack()
            entry_fecha = ctk.CTkEntry(editor)
            entry_fecha.insert(0, orden.get("fecha_entrega", "") or "")
            entry_fecha.pack(pady=4)

            cont_items = ctk.CTkScrollableFrame(editor, height=320)
            cont_items.pack(fill="both", expand=True, padx=6, pady=8)

            entradas: list[tuple[str, str, ctk.CTkEntry, ctk.CTkEntry]] = []
            for item in orden.get("items", []):
                producto_id = str(item.get("producto_id"))
                nombre = item.get("nombre", producto_id)
                solicitada = int(item.get("cantidad", 0))
                confirmada = item.get("cantidad_confirmada") or solicitada
                precio = float(item.get("precio_unit", 0.0))

                fila = ctk.CTkFrame(cont_items)
                fila.pack(fill="x", padx=4, pady=3)
                ctk.CTkLabel(
                    fila,
                    text=f"{nombre} (solicitado {solicitada})",
                ).pack(anchor="w")

                sub = ctk.CTkFrame(fila)
                sub.pack(fill="x", pady=2)
                ctk.CTkLabel(sub, text="Cantidad confirmada").pack(side="left", padx=4)
                entry_cantidad = ctk.CTkEntry(sub, width=80)
                entry_cantidad.insert(0, str(confirmada))
                entry_cantidad.pack(side="left")

                ctk.CTkLabel(sub, text="Precio unitario").pack(side="left", padx=6)
                entry_precio = ctk.CTkEntry(sub, width=100)
                entry_precio.insert(0, f"{precio:.2f}")
                entry_precio.pack(side="left")

                entradas.append((producto_id, nombre, entry_cantidad, entry_precio))

            ctk.CTkLabel(editor, text="Nota para la tienda (opcional)").pack(pady=4)
            txt_nota = ctk.CTkTextbox(editor, height=60)
            txt_nota.insert("1.0", orden.get("nota_proveedor", ""))
            txt_nota.pack(fill="x", padx=6, pady=4)

            def guardar() -> None:
                items_confirmados: list[ProviderOrderItemUpdate] = []
                for producto_id, nombre, entry_cant, entry_precio in entradas:
                    try:
                        cantidad = int(entry_cant.get().strip())
                        precio_val = float(entry_precio.get().strip() or 0.0)
                        if cantidad <= 0 or precio_val < 0:
                            raise ValueError
                    except Exception:
                        messagebox.showerror("Ordenes", f"Datos invalidos para {nombre}")
                        return
                    items_confirmados.append(
                        ProviderOrderItemUpdate(
                            producto_id=producto_id,
                            cantidad_confirmada=cantidad,
                            precio_unit=precio_val,
                        )
                    )
                if not items_confirmados:
                    messagebox.showwarning("Ordenes", "Agrega al menos un producto")
                    return

                data = ProviderOrderConfirmation(
                    orden_id=oid,
                    items=items_confirmados,
                    fecha_entrega=entry_fecha.get().strip() or None,
                    nota=txt_nota.get("1.0", "end").strip(),
                )
                try:
                    self.controller.confirm(data)
                except Exception as exc:
                    messagebox.showerror("Ordenes", str(exc))
                    return
                messagebox.showinfo("Ordenes", "Orden confirmada")
                editor.destroy()
                load()

            botones = ctk.CTkFrame(editor)
            botones.pack(fill="x", padx=10, pady=10)
            ctk.CTkButton(botones, text="Cancelar", command=editor.destroy).pack(side="right", padx=6)
            ctk.CTkButton(botones, text="Confirmar orden", command=guardar).pack(side="right", padx=6)

        barra = ctk.CTkFrame(window)
        barra.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(barra, text="Confirmar", command=confirmar).pack(side="left", padx=6)
        ctk.CTkButton(barra, text="Actualizar", command=load).pack(side="left", padx=6)

        self.bus.subscribe("ordenes:cambio", lambda _=None: load())
        load()


__all__ = ["ProviderOrdersView"]
