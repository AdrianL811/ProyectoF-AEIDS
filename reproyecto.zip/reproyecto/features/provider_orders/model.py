from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass(slots=True)
class ProviderOrdersFilter:
    proveedor: str
    estado: Optional[str] = None
    solo_factura_pendiente: bool = False


@dataclass(slots=True)
class ProviderOrderItemUpdate:
    producto_id: str
    cantidad_confirmada: int
    precio_unit: float


@dataclass(slots=True)
class ProviderOrderConfirmation:
    orden_id: str
    items: List[ProviderOrderItemUpdate] = field(default_factory=list)
    fecha_entrega: Optional[str] = None
    nota: str = ""


__all__ = ["ProviderOrdersFilter", "ProviderOrderItemUpdate", "ProviderOrderConfirmation"]
