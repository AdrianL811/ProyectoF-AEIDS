from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from ..base import FeatureController
from .model import (
    ProviderOrderConfirmation,
    ProviderOrderItemUpdate,
    ProviderOrdersFilter,
)


@dataclass
class ProviderOrdersController(FeatureController):
    """Consulta ordenes de compra pertenecientes a un proveedor."""

    def providers(self) -> List[Dict[str, Any]]:
        return self.services.providers.list()

    def find(self, filtros: ProviderOrdersFilter) -> List[Dict[str, Any]]:
        return self.services.orders.orders_by_provider(
            filtros.proveedor,
            filtros.estado,
            filtros.solo_factura_pendiente,
        )

    def update_status(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.services.orders.update(oid, cambios)

    def get(self, oid: str) -> Dict[str, Any]:
        return self.services.orders.get(oid)

    def confirm(self, data: ProviderOrderConfirmation) -> None:
        items_payload = [
            {
                "producto_id": item.producto_id,
                "cantidad_confirmada": item.cantidad_confirmada,
                "precio_unit": item.precio_unit,
            }
            for item in data.items
        ]
        self.services.orders.confirm_purchase_order(
            data.orden_id,
            items_payload,
            data.fecha_entrega,
            data.nota or "",
        )


__all__ = ["ProviderOrdersController"]
