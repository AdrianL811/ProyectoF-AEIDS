from __future__ import annotations

from reproyecto.features.product_supplier.view_base import ProductSupplierView

from .controller import UpdateProductSupplierController


class UpdateProductSupplierView(ProductSupplierView):
    def __init__(self, context, controller: UpdateProductSupplierController) -> None:
        super().__init__(
            context,
            controller,
            "Actualizar Proveedor de Producto",
            "Proveedor actualizado",
        )


__all__ = ["UpdateProductSupplierView"]
