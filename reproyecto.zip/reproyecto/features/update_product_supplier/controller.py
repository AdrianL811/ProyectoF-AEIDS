from __future__ import annotations

from dataclasses import dataclass

from ..product_supplier.base import ProductSupplierBaseController
from .model import ProductSupplierUpdate


@dataclass
class UpdateProductSupplierController(ProductSupplierBaseController):
    """Actualiza el proveedor asociado a un producto existente."""

    def update(self, data: ProductSupplierUpdate) -> None:
        self.set_supplier(data.producto_id, data.proveedor)


__all__ = ["UpdateProductSupplierController"]
