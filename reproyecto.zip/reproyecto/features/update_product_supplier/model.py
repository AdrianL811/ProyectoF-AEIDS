from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ProductSupplierUpdate:
    producto_id: str
    proveedor: str


__all__ = ["ProductSupplierUpdate"]
