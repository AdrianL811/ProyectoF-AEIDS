"""Subpaquete que agrupa los modulos por funcionalidad siguiendo el patron MVC."""

from __future__ import annotations

__all__ = []
