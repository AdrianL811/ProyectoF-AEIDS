from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass(slots=True)
class ProductFilters:
    """Filtro simple basado en texto para listar productos."""

    texto: str = ""

    def as_query(self) -> Dict[str, object]:
        if not self.texto:
            return {}
        criterio = {
            "$or": [
                {"nombre": {"$regex": self.texto, "$options": "i"}},
                {"proveedor": {"$regex": self.texto, "$options": "i"}},
            ]
        }
        return criterio


__all__ = ["ProductFilters"]
