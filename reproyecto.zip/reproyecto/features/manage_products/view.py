from __future__ import annotations

from typing import Callable, Dict, List

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, export_tree, populate_table

from ..manage_products.controller import ManageProductsController
from ..manage_products.model import ProductFilters
from ..register_product.view import RegisterProductView


class ManageProductsView(FeatureView):
    def __init__(
        self,
        context,
        controller: ManageProductsController,
        register_view_factory: Callable[[], RegisterProductView],
    ) -> None:
        super().__init__(context)
        self.controller = controller
        self.register_view_factory = register_view_factory

    def show(self) -> None:
        window = self.open_window("Gestion de Productos")
        entry_filter = ctk.CTkEntry(window, placeholder_text="Buscar por nombre / proveedor...")
        entry_filter.pack(pady=6)

        columns = ("ID", "Nombre", "Marca", "Categoria", "Cantidad", "Precio", "Proveedor", "Caducidad")
        tree = build_table(window, columns)

        def load() -> None:
            filtros = ProductFilters(entry_filter.get().strip())
            registros = self.controller.list(filtros)
            rows: List[List[object]] = []
            for prod in registros:
                rows.append(
                    [
                        str(prod.get("_id")),
                        prod.get("nombre", ""),
                        prod.get("marca", ""),
                        prod.get("categoria", ""),
                        int(prod.get("cantidad", 0)),
                        float(prod.get("precio", 0.0)),
                        prod.get("proveedor", ""),
                        prod.get("fecha_caducidad", "N/A"),
                    ]
                )
            populate_table(tree, rows)

        def nuevo() -> None:
            view = self.register_view_factory()
            view.show(on_saved=load)

        def editar() -> None:
            selection = tree.selection()
            if not selection:
                messagebox.showwarning("Productos", "Selecciona un producto")
                return
            producto_id = str(tree.item(selection[0])["values"][0])
            producto = self.controller.get(producto_id)
            editor = ctk.CTkToplevel(window)
            editor.title("Editar producto")
            editor.geometry("420x600")
            entradas: Dict[str, ctk.CTkEntry] = {}
            for campo, placeholder in (
                ("nombre", "Nombre"),
                ("marca", "Marca"),
                ("categoria", "Categoria"),
                ("cantidad", "Cantidad"),
                ("precio", "Precio"),
                ("proveedor", "Proveedor"),
                ("fecha_caducidad", "Fecha caducidad (opcional)"),
            ):
                ctk.CTkLabel(editor, text=placeholder).pack(pady=2)
                entry = ctk.CTkEntry(editor)
                value = producto.get(campo, "")
                entry.insert(0, str(value) if value is not None else "")
                entry.pack(pady=2)
                entradas[campo] = entry

            def guardar_cambios() -> None:
                try:
                    cambios = {
                        "nombre": entradas["nombre"].get().strip(),
                        "marca": entradas["marca"].get().strip(),
                        "categoria": entradas["categoria"].get().strip(),
                        "cantidad": int(entradas["cantidad"].get()),
                        "precio": float(entradas["precio"].get()),
                        "proveedor": entradas["proveedor"].get().strip(),
                        "fecha_caducidad": entradas["fecha_caducidad"].get().strip() or None,
                    }
                except Exception:
                    messagebox.showerror("Productos", "Cantidad debe ser entero y precio decimal")
                    return
                self.controller.update(producto_id, cambios)
                messagebox.showinfo("Productos", "Producto actualizado")
                editor.destroy()
                load()

            ctk.CTkButton(editor, text="Guardar", command=guardar_cambios).pack(pady=12)

        def eliminar() -> None:
            selection = tree.selection()
            if not selection:
                messagebox.showwarning("Productos", "Selecciona un producto")
                return
            producto_id = str(tree.item(selection[0])["values"][0])
            if messagebox.askyesno("Productos", "Eliminar el producto seleccionado?"):
                self.controller.delete(producto_id)
                load()

        toolbar = ctk.CTkFrame(window)
        toolbar.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(toolbar, text="Buscar", command=load).pack(side="left", padx=4)
        ctk.CTkButton(toolbar, text="Nuevo", command=nuevo).pack(side="left", padx=4)
        ctk.CTkButton(toolbar, text="Editar", command=editar).pack(side="left", padx=4)
        ctk.CTkButton(toolbar, text="Eliminar", command=eliminar).pack(side="left", padx=4)
        ctk.CTkButton(toolbar, text="Exportar Excel", command=lambda: export_tree(tree, "inventario.xlsx")).pack(
            side="left", padx=4
        )
        ctk.CTkButton(
            toolbar,
            text="Exportar CSV",
            command=lambda: export_tree(tree, "inventario.xlsx", csv_only=True),
        ).pack(side="left", padx=4)

        self.bus.subscribe("productos:cambio", lambda _=None: load())
        load()


__all__ = ["ManageProductsView"]
