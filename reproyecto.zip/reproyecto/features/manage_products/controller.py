from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from ..base import FeatureController
from ..productos.model import Producto
from ..proveedores.model import Proveedor
from .model import ProductFilters


@dataclass
class ManageProductsController(FeatureController):
    """Opera sobre la tabla general de productos."""

    def list(self, filtros: ProductFilters) -> List[Dict[str, Any]]:
        query = filtros.as_query()
        return self.services.products.list(query if query else None)

    def get(self, producto_id: str) -> Dict[str, Any]:
        return self.services.products.get(producto_id)

    def update(self, producto_id: str, cambios: Dict[str, Any]) -> None:
        self.services.products.update(producto_id, cambios)

    def delete(self, producto_id: str) -> None:
        self.services.products.delete(producto_id)

    def available_providers(self) -> List[Dict[str, Any]]:
        return self.services.providers.list()

    def create(self, producto: Producto) -> str:
        return self.services.products.create(producto)


__all__ = ["ManageProductsController"]
