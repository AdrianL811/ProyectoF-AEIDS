from __future__ import annotations

from dataclasses import dataclass

from ..base import FeatureController
from .model import InventoryAlerts


@dataclass
class AlertsController(FeatureController):
    """Expone las alertas generadas por el servicio de inventario."""

    def current_alerts(self) -> InventoryAlerts:
        data = self.services.alerts.current_alerts()
        return InventoryAlerts(
            stock_bajo=list(data.get("stock_bajo", [])),
            proxima_caducidad=list(data.get("proxima_caducidad", [])),
        )


__all__ = ["AlertsController"]
