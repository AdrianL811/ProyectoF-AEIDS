from __future__ import annotations

from reproyecto.ui.base_view import FeatureView, ctk
from reproyecto.ui.helpers import build_table, populate_table

from .controller import AlertsController


class AlertsView(FeatureView):
    def __init__(self, context, controller: AlertsController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Alertas", "980x520")
        data = self.controller.current_alerts()

        ctk.CTkLabel(window, text="Stock bajo (<10)", font=("Arial", 16)).pack(anchor="w", padx=12, pady=6)
        columns = ("ID", "Nombre", "Cantidad", "Proveedor", "Caducidad")
        low_table = build_table(window, columns)
        populate_table(
            low_table,
            [
                [
                    str(prod.get("_id")),
                    prod.get("nombre", ""),
                    int(prod.get("cantidad", 0)),
                    prod.get("proveedor", ""),
                    prod.get("fecha_caducidad", "N/A"),
                ]
                for prod in data.stock_bajo
            ],
        )

        ctk.CTkLabel(window, text="Proxima caducidad (15 dias)", font=("Arial", 16)).pack(anchor="w", padx=12, pady=6)
        exp_table = build_table(window, columns)
        populate_table(
            exp_table,
            [
                [
                    str(prod.get("_id")),
                    prod.get("nombre", ""),
                    int(prod.get("cantidad", 0)),
                    prod.get("proveedor", ""),
                    prod.get("fecha_caducidad", "N/A"),
                ]
                for prod in data.proxima_caducidad
            ],
        )


__all__ = ["AlertsView"]
