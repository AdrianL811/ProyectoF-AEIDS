from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass(slots=True)
class InventoryAlerts:
    stock_bajo: List[Dict[str, Any]] = field(default_factory=list)
    proxima_caducidad: List[Dict[str, Any]] = field(default_factory=list)


__all__ = ["InventoryAlerts"]
