from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from ..base import FeatureController
from .model import PurchaseOrderRequest


@dataclass
class PurchaseOrdersController(FeatureController):
    """Controlador para la generacion de ordenes de compra."""

    def products(self) -> List[Dict[str, Any]]:
        return self.services.products.list()

    def providers(self) -> List[Dict[str, Any]]:
        return self.services.providers.list()

    def create(self, request: PurchaseOrderRequest) -> str:
        elementos = [
            {"producto_id": item.producto_id, "cantidad": item.cantidad}
            for item in request.items
        ]
        return self.services.orders.create_purchase_order(
            request.proveedor,
            elementos,
            request.fecha_entrega,
        )


__all__ = ["PurchaseOrdersController"]
