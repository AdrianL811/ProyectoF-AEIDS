from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass(slots=True)
class PurchaseOrderItem:
    producto_id: str
    cantidad: int


@dataclass(slots=True)
class PurchaseOrderRequest:
    proveedor: str
    fecha_entrega: str
    items: List[PurchaseOrderItem] = field(default_factory=list)


__all__ = ["PurchaseOrderItem", "PurchaseOrderRequest"]
