from __future__ import annotations

from typing import List

from reproyecto.ui.base_view import FeatureView, ctk, messagebox, tk

from .controller import PurchaseOrdersController
from .model import PurchaseOrderItem, PurchaseOrderRequest


class PurchaseOrdersView(FeatureView):
    def __init__(self, context, controller: PurchaseOrdersController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Crear Orden de Compra", "860x640")
        ctk.CTkLabel(window, text="Crear Orden de Compra", font=("Arial", 18)).pack(pady=10)

        proveedores = [p.get("nombre", "") for p in self.controller.providers() if p.get("nombre")]
        combo_proveedor = ctk.CTkComboBox(window, values=proveedores or [""])
        if proveedores:
            combo_proveedor.set(proveedores[0])
        combo_proveedor.pack(pady=6)

        productos = self.controller.products()
        scroll = ctk.CTkScrollableFrame(window, height=320)
        scroll.pack(fill="both", expand=True, pady=10)

        registros: List[tuple[dict, tk.BooleanVar, tk.StringVar]] = []
        for prod in productos:
            var_sel = tk.BooleanVar()
            var_cant = tk.StringVar(value="0")
            fila = ctk.CTkFrame(scroll)
            fila.pack(fill="x", expand=True, padx=4, pady=2)
            tk.Checkbutton(
                fila,
                text=f"{prod.get('nombre', '')} | Stock: {prod.get('cantidad', 0)}",
                variable=var_sel,
            ).pack(side="left", padx=4)
            tk.Entry(fila, textvariable=var_cant, width=6).pack(side="right", padx=4)
            registros.append((prod, var_sel, var_cant))

        ctk.CTkLabel(window, text="Fecha estimada (YYYY-MM-DD)").pack(pady=6)
        entry_fecha = ctk.CTkEntry(window)
        entry_fecha.pack(pady=4)

        def guardar() -> None:
            proveedor = combo_proveedor.get().strip()
            fecha = entry_fecha.get().strip()
            seleccion: List[PurchaseOrderItem] = []
            for prod, seleccionado, cantidad_var in registros:
                if seleccionado.get():
                    try:
                        cantidad = int(cantidad_var.get())
                        if cantidad <= 0:
                            raise ValueError
                    except Exception:
                        messagebox.showerror("Orden", f"Cantidad invalida para {prod.get('nombre', '')}")
                        return
                    seleccion.append(PurchaseOrderItem(producto_id=str(prod.get("_id")), cantidad=cantidad))
            if not proveedor or not fecha or not seleccion:
                messagebox.showwarning("Orden", "Selecciona proveedor, fecha e items")
                return
            request = PurchaseOrderRequest(proveedor=proveedor, fecha_entrega=fecha, items=seleccion)
            try:
                orden_id = self.controller.create(request)
                messagebox.showinfo("Orden", f"Orden de compra creada {orden_id}")
                entry_fecha.delete(0, "end")
                for _, var_sel, var_cant in registros:
                    var_sel.set(False)
                    var_cant.set("0")
            except Exception as err:
                messagebox.showerror("Orden", str(err))

        ctk.CTkButton(window, text="Guardar", command=guardar).pack(pady=12)


__all__ = ["PurchaseOrdersView"]
