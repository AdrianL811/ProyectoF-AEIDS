from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..base import FeatureController
from ..proveedores.model import Proveedor
from ..usuarios.model import Usuario
from .model import ProviderFormData


@dataclass
class ManageProvidersController(FeatureController):
    """Abstrae operaciones sobre proveedores para la capa de vista."""

    def list(self) -> List[Dict[str, Any]]:
        return self.services.providers.list()

    def create(self, data: ProviderFormData) -> str:
        if not data.usuario or not data.password:
            raise ValueError("Usuario y contraseña son obligatorios")
        if self.services.users.get_by_username(data.usuario):
            raise ValueError("El usuario ya existe")
        proveedor = Proveedor(
            nombre=data.nombre,
            empresa=data.empresa,
            telefono=data.telefono,
            correo=data.correo,
            usuario=data.usuario,
        )
        prov_id = self.services.providers.create(proveedor)
        usuario = Usuario(
            usuario=data.usuario,
            password=data.password,
            rol="proveedor",
            nombre=data.nombre,
        )
        try:
            user_id = self.services.users.create(usuario)
        except Exception:
            self.services.providers.delete(prov_id)
            raise
        self.services.providers.update(prov_id, {"usuario_id": user_id})
        return prov_id

    def update(self, oid: str, data: ProviderFormData) -> None:
        proveedor = self.services.providers.get(oid)
        if data.usuario != proveedor.get("usuario"):
            if self.services.users.get_by_username(data.usuario):
                raise ValueError("El usuario ya existe")
        cambios = {
            "nombre": data.nombre,
            "empresa": data.empresa,
            "telefono": data.telefono,
            "correo": data.correo,
            "usuario": data.usuario,
        }
        self.services.providers.update(oid, cambios)
        self._sync_user(proveedor, data)

    def delete(self, oid: str) -> None:
        proveedor = self.services.providers.get(oid)
        self.services.providers.delete(oid)
        self._delete_user_for_provider(proveedor)

    def get(self, oid: str) -> Dict[str, Any]:
        return self.services.providers.get(oid)

    # ---- helpers ----
    def _sync_user(self, proveedor: Dict[str, Any], data: ProviderFormData) -> None:
        update_payload: Dict[str, Any] = {
            "usuario": data.usuario,
            "nombre": data.nombre,
        }
        if data.password:
            update_payload["password"] = data.password

        user_id = proveedor.get("usuario_id")
        if user_id:
            self.services.users.update(str(user_id), update_payload)
            return

        existing = self.services.users.get_by_username(proveedor.get("usuario", ""))
        if existing:
            user_id = str(existing.get("_id"))
            self.services.users.update(user_id, update_payload)
            prov_id = proveedor.get("_id")
            if prov_id is not None:
                self.services.providers.update(str(prov_id), {"usuario_id": user_id})
            return

        if data.password:
            nuevo = Usuario(
                usuario=data.usuario,
                password=data.password,
                rol="proveedor",
                nombre=data.nombre,
            )
            user_id = self.services.users.create(nuevo)
            prov_id = proveedor.get("_id")
            if prov_id is not None:
                self.services.providers.update(str(prov_id), {"usuario_id": user_id})

    def _delete_user_for_provider(self, proveedor: Optional[Dict[str, Any]]) -> None:
        if not proveedor:
            return
        user_id = proveedor.get("usuario_id")
        if user_id:
            self.services.users.delete(str(user_id))
            return
        username = proveedor.get("usuario")
        if username:
            existing = self.services.users.get_by_username(username)
            if existing:
                self.services.users.delete(str(existing.get("_id")))


__all__ = ["ManageProvidersController"]
