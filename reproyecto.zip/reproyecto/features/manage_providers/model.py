from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ProviderFormData:
    nombre: str
    empresa: str
    telefono: str
    correo: str
    usuario: str
    password: str = ""


__all__ = ["ProviderFormData"]
