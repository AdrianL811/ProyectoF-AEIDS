from __future__ import annotations

from typing import Dict, List

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .controller import ManageProvidersController
from .model import ProviderFormData


class ManageProvidersView(FeatureView):
    def __init__(self, context, controller: ManageProvidersController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Gestion de Proveedores")
        columns = ("ID", "Nombre", "Empresa", "Telefono", "Correo", "Usuario")
        tree = build_table(window, columns)

        form = ctk.CTkFrame(window)
        form.pack(fill="x", padx=10, pady=8)
        entry_nombre = ctk.CTkEntry(form, placeholder_text="Nombre")
        entry_nombre.pack(side="left", padx=4)
        entry_empresa = ctk.CTkEntry(form, placeholder_text="Empresa")
        entry_empresa.pack(side="left", padx=4)
        entry_telefono = ctk.CTkEntry(form, placeholder_text="Telefono")
        entry_telefono.pack(side="left", padx=4)
        entry_correo = ctk.CTkEntry(form, placeholder_text="Correo")
        entry_correo.pack(side="left", padx=4)
        entry_usuario = ctk.CTkEntry(form, placeholder_text="Usuario")
        entry_usuario.pack(side="left", padx=4)
        entry_password = ctk.CTkEntry(form, placeholder_text="Contraseña", show="*")
        entry_password.pack(side="left", padx=4)

        def limpiar_form() -> None:
            entry_nombre.delete(0, "end")
            entry_empresa.delete(0, "end")
            entry_telefono.delete(0, "end")
            entry_correo.delete(0, "end")
            entry_usuario.delete(0, "end")
            entry_password.delete(0, "end")

        def load() -> None:
            proveedores = self.controller.list()
            rows: List[List[object]] = []
            for prov in proveedores:
                rows.append(
                    [
                        str(prov.get("_id")),
                        prov.get("nombre", ""),
                        prov.get("empresa", ""),
                        prov.get("telefono", ""),
                        prov.get("correo", ""),
                        prov.get("usuario", ""),
                    ]
                )
            populate_table(tree, rows)

        def agregar() -> None:
            data = ProviderFormData(
                nombre=entry_nombre.get().strip(),
                empresa=entry_empresa.get().strip(),
                telefono=entry_telefono.get().strip(),
                correo=entry_correo.get().strip(),
                usuario=entry_usuario.get().strip(),
                password=entry_password.get().strip(),
            )
            if not data.nombre or not data.empresa or not data.usuario or not data.password:
                messagebox.showwarning(
                    "Proveedor", "Nombre, empresa, usuario y contraseña son obligatorios"
                )
                return
            try:
                self.controller.create(data)
            except ValueError as exc:
                messagebox.showerror("Proveedor", str(exc))
                return
            messagebox.showinfo("Proveedor", "Proveedor registrado y usuario creado")
            limpiar_form()
            load()

        def editar() -> None:
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Proveedor", "Selecciona un registro")
                return
            oid = str(tree.item(sel[0])["values"][0])
            proveedor = self.controller.get(oid)
            editor = ctk.CTkToplevel(window)
            editor.geometry("420x460")
            editor.title("Editar Proveedor")
            entradas: Dict[str, ctk.CTkEntry] = {}
            for campo in ("nombre", "empresa", "telefono", "correo", "usuario"):
                ctk.CTkLabel(editor, text=campo.capitalize()).pack(pady=4)
                entry = ctk.CTkEntry(editor)
                entry.insert(0, proveedor.get(campo, ""))
                entry.pack(pady=4)
                entradas[campo] = entry
            ctk.CTkLabel(editor, text="Contraseña (dejar vacio para no cambiar)").pack(pady=4)
            entry_pass = ctk.CTkEntry(editor, show="*")
            entry_pass.pack(pady=4)

            def guardar() -> None:
                data = ProviderFormData(
                    nombre=entradas["nombre"].get().strip(),
                    empresa=entradas["empresa"].get().strip(),
                    telefono=entradas["telefono"].get().strip(),
                    correo=entradas["correo"].get().strip(),
                    usuario=entradas["usuario"].get().strip(),
                    password=entry_pass.get().strip(),
                )
                if not data.nombre or not data.empresa or not data.usuario:
                    messagebox.showwarning(
                        "Proveedor", "Nombre, empresa y usuario son obligatorios"
                    )
                    return
                try:
                    self.controller.update(oid, data)
                except ValueError as exc:
                    messagebox.showerror("Proveedor", str(exc))
                    return
                editor.destroy()
                load()

            ctk.CTkButton(editor, text="Guardar", command=guardar).pack(pady=12)

        def eliminar() -> None:
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Proveedor", "Selecciona un registro")
                return
            oid = str(tree.item(sel[0])["values"][0])
            if messagebox.askyesno("Proveedor", "Eliminar el proveedor seleccionado?"):
                self.controller.delete(oid)
                load()

        acciones = ctk.CTkFrame(window)
        acciones.pack(fill="x", padx=10, pady=6)
        ctk.CTkButton(acciones, text="Agregar", command=agregar).pack(side="left", padx=4)
        ctk.CTkButton(acciones, text="Editar", command=editar).pack(side="left", padx=4)
        ctk.CTkButton(acciones, text="Eliminar", command=eliminar).pack(side="left", padx=4)
        ctk.CTkButton(acciones, text="Limpiar", command=limpiar_form).pack(side="left", padx=4)

        self.bus.subscribe("proveedores:cambio", lambda _=None: load())
        load()


__all__ = ["ManageProvidersView"]
