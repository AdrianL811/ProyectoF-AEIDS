from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(slots=True)
class Proveedor:
    """Entidad de proveedor asociada a productos y ordenes."""

    nombre: str
    empresa: str
    telefono: str
    correo: str
    usuario: str = ""
    usuario_id: Optional[str] = None
    _id: Optional[str] = None


__all__ = ["Proveedor"]
