from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional


@dataclass(slots=True)
class OrdenItem:
    """Elemento que compone una orden de venta o compra."""

    producto_id: str
    nombre: str
    cantidad: int
    precio_unit: float
    cantidad_confirmada: Optional[int] = None
    descuento: int = 0


@dataclass(slots=True)
class Orden:
    """Orden registrada en el sistema (venta o compra)."""

    proveedor_o_cliente: str
    fecha: str
    items: List[OrdenItem]
    total: float
    tipo: str = "venta"
    estado: str = "pendiente"
    fecha_entrega: Optional[str] = None
    facturada: bool = False
    _id: Optional[str] = None


__all__ = ["Orden", "OrdenItem"]
