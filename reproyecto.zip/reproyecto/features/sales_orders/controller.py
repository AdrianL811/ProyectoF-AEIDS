from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..base import FeatureController
from .model import SaleOrderItem, SaleOrderRequest


@dataclass
class SalesOrdersController(FeatureController):
    """Gestiona la creacion de ordenes de venta y su facturacion inmediata."""

    def products(self) -> List[Dict[str, Any]]:
        return self.services.products.list()

    def promotional_price(self, producto_id: str) -> float:
        producto = self.services.products.get(producto_id)
        return self.services.promotions.precio_con_promo(producto)

    def create_order(self, request: SaleOrderRequest) -> Dict[str, str]:
        payload = [{"producto_id": item.producto_id, "cantidad": item.cantidad} for item in request.items]
        usuario = self._current_user_name()
        orden_id, invoice_items = self.services.orders.create_sale_order(
            request.cliente,
            payload,
            usuario,
        )
        factura_id = self.services.invoices.create(orden_id, invoice_items)
        return {"orden_id": orden_id, "factura_id": factura_id}

    def _current_user_name(self) -> Optional[str]:
        current = self.services.auth.current_user()
        if not current:
            return None
        return current.get("nombre") or current.get("usuario")


__all__ = ["SalesOrdersController"]
