from __future__ import annotations

from dataclasses import dataclass, field
from typing import List


@dataclass(slots=True)
class SaleOrderItem:
    producto_id: str
    cantidad: int


@dataclass(slots=True)
class SaleOrderRequest:
    cliente: str
    items: List[SaleOrderItem] = field(default_factory=list)


__all__ = ["SaleOrderItem", "SaleOrderRequest"]
