from __future__ import annotations

from typing import Dict, List

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, clear_table

from .controller import SalesOrdersController
from .model import SaleOrderItem, SaleOrderRequest


class SalesOrdersView(FeatureView):
    def __init__(self, context, controller: SalesOrdersController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Ordenes / Facturas (Venta)", "860x640")
        ctk.CTkLabel(window, text="Orden de Venta", font=("Arial", 18)).pack(pady=10)

        entry_cliente = ctk.CTkEntry(window, placeholder_text="Cliente")
        entry_cliente.pack(pady=6)

        productos = self.controller.products()
        opciones = [f"{p.get('nombre', '')} | {p.get('_id')}" for p in productos]
        ctk.CTkLabel(window, text="Agregar producto").pack(pady=6)
        combo_producto = ctk.CTkComboBox(window, values=opciones or [""])
        if opciones:
            combo_producto.set(opciones[0])
        combo_producto.pack(pady=4)

        entry_cantidad = ctk.CTkEntry(window, placeholder_text="Cantidad")
        entry_cantidad.insert(0, "1")
        entry_cantidad.pack(pady=4)

        columnas = ("ProductoID", "Nombre", "Cantidad", "PrecioUnit")
        tabla = build_table(window, columnas)

        items: List[Dict[str, object]] = []

        def agregar_item() -> None:
            try:
                seleccionado = combo_producto.get()
                producto_id = seleccionado.split("|")[-1].strip()
                cantidad = int(entry_cantidad.get().strip())
                if cantidad <= 0:
                    raise ValueError
                producto = next((p for p in productos if str(p.get("_id")) == producto_id), None)
                if not producto:
                    raise ValueError
                precio = self.controller.promotional_price(producto_id)
                items.append(
                    {
                        "producto_id": producto_id,
                        "nombre": producto.get("nombre", ""),
                        "cantidad": cantidad,
                        "precio_unitario": precio,
                    }
                )
                tabla.insert("", "end", values=(producto_id, producto.get("nombre", ""), cantidad, precio))
            except Exception:
                messagebox.showerror("Orden", "Datos invalidos")

        def facturar() -> None:
            if not items:
                messagebox.showwarning("Orden", "Agrega articulos")
                return
            cliente = entry_cliente.get().strip() or "Mostrador"
            request = SaleOrderRequest(
                cliente=cliente,
                items=[SaleOrderItem(producto_id=item["producto_id"], cantidad=item["cantidad"]) for item in items],
            )
            try:
                resultado = self.controller.create_order(request)
                messagebox.showinfo(
                    "Orden",
                    f"Orden creada {resultado['orden_id']} | Factura {resultado['factura_id']}",
                )
                items.clear()
                clear_table(tabla)
            except Exception as err:
                messagebox.showerror("Orden", str(err))

        botones = ctk.CTkFrame(window)
        botones.pack(pady=12)
        ctk.CTkButton(botones, text="Agregar", command=agregar_item).pack(side="left", padx=6)
        ctk.CTkButton(botones, text="Facturar", command=facturar).pack(side="left", padx=6)


__all__ = ["SalesOrdersView"]
