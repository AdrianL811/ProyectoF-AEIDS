from __future__ import annotations

from typing import Callable, Optional

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from .controller import RegisterProductController
from .model import ProductFormData


class RegisterProductView(FeatureView):
    def __init__(self, context, controller: RegisterProductController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self, on_saved: Optional[Callable[[], None]] = None) -> None:
        window = ctk.CTkToplevel(self.app)
        window.geometry("420x640")
        window.title("Registrar Producto")

        ctk.CTkLabel(window, text="Nuevo Producto", font=("Arial", 20)).pack(pady=12)

        entry_nombre = ctk.CTkEntry(window, placeholder_text="Nombre")
        entry_nombre.pack(pady=4)
        entry_marca = ctk.CTkEntry(window, placeholder_text="Marca")
        entry_marca.pack(pady=4)
        entry_categoria = ctk.CTkEntry(window, placeholder_text="Categoria")
        entry_categoria.pack(pady=4)
        entry_cantidad = ctk.CTkEntry(window, placeholder_text="Cantidad")
        entry_cantidad.pack(pady=4)
        entry_precio = ctk.CTkEntry(window, placeholder_text="Precio")
        entry_precio.pack(pady=4)

        proveedores = [p.get("nombre", "") for p in self.controller.providers() if p.get("nombre")]
        ctk.CTkLabel(window, text="Proveedor").pack(pady=4)
        combo_proveedor = ctk.CTkComboBox(window, values=proveedores or [""])
        if proveedores:
            combo_proveedor.set(proveedores[0])
        combo_proveedor.pack(pady=4)

        ctk.CTkLabel(window, text="Fecha de caducidad (opcional)").pack(pady=2)
        entry_caducidad = ctk.CTkEntry(window, placeholder_text="YYYY-MM-DD")
        entry_caducidad.pack(pady=4)

        def guardar() -> None:
            try:
                data = ProductFormData(
                    nombre=entry_nombre.get().strip(),
                    marca=entry_marca.get().strip(),
                    categoria=entry_categoria.get().strip(),
                    cantidad=int(entry_cantidad.get().strip() or 0),
                    precio=float(entry_precio.get().strip() or 0.0),
                    proveedor=combo_proveedor.get().strip(),
                    fecha_caducidad=(entry_caducidad.get().strip() or None),
                )
            except Exception:
                messagebox.showerror("Producto", "Cantidad debe ser entero y precio decimal")
                return

            if not data.nombre or not data.marca or not data.categoria:
                messagebox.showwarning("Producto", "Completa los campos obligatorios")
                return
            self.controller.register(data)
            messagebox.showinfo("Producto", "Producto registrado")
            if on_saved:
                on_saved()
            window.destroy()

        ctk.CTkButton(window, text="Guardar", command=guardar).pack(pady=16)


__all__ = ["RegisterProductView"]
