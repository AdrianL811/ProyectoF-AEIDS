from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass(slots=True)
class ProductFormData:
    nombre: str
    marca: str
    categoria: str
    cantidad: int
    precio: float
    proveedor: str
    fecha_caducidad: Optional[str] = None


__all__ = ["ProductFormData"]
