from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

from ..base import FeatureController
from ..productos.model import Producto
from .model import ProductFormData


@dataclass
class RegisterProductController(FeatureController):
    """Controlador para el formulario de alta de productos."""

    def providers(self) -> List[Dict[str, str]]:
        return self.services.providers.list()

    def register(self, data: ProductFormData) -> str:
        producto = Producto(
            nombre=data.nombre,
            marca=data.marca,
            categoria=data.categoria,
            cantidad=data.cantidad,
            precio=data.precio,
            proveedor=data.proveedor,
            fecha_caducidad=data.fecha_caducidad,
        )
        return self.services.products.create(producto)


__all__ = ["RegisterProductController"]
