from __future__ import annotations

from typing import Dict, List

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .controller import ManagePromotionsController
from .model import PromotionFormData


class ManagePromotionsView(FeatureView):
    def __init__(self, context, controller: ManagePromotionsController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self) -> None:
        window = self.open_window("Promociones")
        columns = ("ID", "Producto", "Descuento", "Inicio", "Fin", "Activa")
        tree = build_table(window, columns)

        def load() -> None:
            promos = self.controller.list()
            rows: List[List[object]] = []
            for promo in promos:
                rows.append(
                    [
                        str(promo.get("_id")),
                        promo.get("producto_id", ""),
                        int(promo.get("descuento", 0)),
                        promo.get("inicio", ""),
                        promo.get("fin", ""),
                        bool(promo.get("activa", True)),
                    ]
                )
            populate_table(tree, rows)

        def seleccionar_producto() -> List[str]:
            productos = self.controller.products()
            return [f"{p.get('nombre','')} | {p.get('_id')}" for p in productos]

        def nueva() -> None:
            form = ctk.CTkToplevel(window)
            form.geometry("420x360")
            form.title("Nueva promocion")
            opciones = seleccionar_producto() or [""]
            ctk.CTkLabel(form, text="Producto").pack(pady=4)
            combo_producto = ctk.CTkComboBox(form, values=opciones)
            if opciones and opciones[0]:
                combo_producto.set(opciones[0])
            combo_producto.pack(pady=4)
            entry_descuento = ctk.CTkEntry(form, placeholder_text="Descuento %")
            entry_descuento.pack(pady=4)
            entry_inicio = ctk.CTkEntry(form, placeholder_text="Inicio YYYY-MM-DD")
            entry_inicio.pack(pady=4)
            entry_fin = ctk.CTkEntry(form, placeholder_text="Fin YYYY-MM-DD")
            entry_fin.pack(pady=4)

            def guardar() -> None:
                try:
                    selection = combo_producto.get()
                    producto_id = selection.split("|")[-1].strip()
                    data = PromotionFormData(
                        producto_id=producto_id,
                        descuento=int(entry_descuento.get().strip()),
                        inicio=entry_inicio.get().strip(),
                        fin=entry_fin.get().strip(),
                        activa=True,
                    )
                except Exception:
                    messagebox.showerror("Promociones", "Datos invalidos")
                    return
                if not data.producto_id or not data.inicio or not data.fin:
                    messagebox.showwarning("Promociones", "Completa todos los campos")
                    return
                self.controller.create(data)
                form.destroy()
                load()

            ctk.CTkButton(form, text="Guardar", command=guardar).pack(pady=12)

        def editar() -> None:
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Promociones", "Selecciona una promocion")
                return
            oid = str(tree.item(sel[0])["values"][0])
            promo = next((p for p in self.controller.list() if str(p.get("_id")) == oid), None)
            if not promo:
                messagebox.showerror("Promociones", "Promocion no encontrada")
                return
            form = ctk.CTkToplevel(window)
            form.geometry("420x420")
            form.title("Editar promocion")
            entradas: Dict[str, ctk.CTkEntry] = {}
            for campo in ("producto_id", "descuento", "inicio", "fin", "activa"):
                ctk.CTkLabel(form, text=campo.capitalize()).pack(pady=4)
                entry = ctk.CTkEntry(form)
                entry.insert(0, str(promo.get(campo, "")))
                entry.pack(pady=4)
                entradas[campo] = entry

            def guardar_cambios() -> None:
                try:
                    cambios = {
                        "producto_id": entradas["producto_id"].get().strip(),
                        "descuento": int(entradas["descuento"].get()),
                        "inicio": entradas["inicio"].get().strip(),
                        "fin": entradas["fin"].get().strip(),
                        "activa": entradas["activa"].get().strip().lower() in {"true", "1", "si", "yes"},
                    }
                except Exception:
                    messagebox.showerror("Promociones", "Datos invalidos")
                    return
                self.controller.update(oid, cambios)
                form.destroy()
                load()

            ctk.CTkButton(form, text="Guardar", command=guardar_cambios).pack(pady=12)

        def eliminar() -> None:
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Promociones", "Selecciona una promocion")
                return
            oid = str(tree.item(sel[0])["values"][0])
            if messagebox.askyesno("Promociones", "Eliminar la promocion seleccionada?"):
                self.controller.delete(oid)
                load()

        acciones = ctk.CTkFrame(window)
        acciones.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(acciones, text="Nueva", command=nueva).pack(side="left", padx=4)
        ctk.CTkButton(acciones, text="Editar", command=editar).pack(side="left", padx=4)
        ctk.CTkButton(acciones, text="Eliminar", command=eliminar).pack(side="left", padx=4)

        self.bus.subscribe("promos:cambio", lambda _=None: load())
        load()


__all__ = ["ManagePromotionsView"]
