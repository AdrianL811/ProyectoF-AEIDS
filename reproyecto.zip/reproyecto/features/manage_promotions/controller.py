from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List

from ..base import FeatureController
from ..promociones.model import Promocion
from .model import PromotionFormData


@dataclass
class ManagePromotionsController(FeatureController):
    """Gestor de promociones sobre productos."""

    def list(self) -> List[Dict[str, Any]]:
        return self.services.promotions.list()

    def create(self, data: PromotionFormData) -> str:
        promo = Promocion(
            producto_id=data.producto_id,
            descuento=data.descuento,
            inicio=data.inicio,
            fin=data.fin,
            activa=data.activa,
        )
        return self.services.promotions.create(promo)

    def update(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.services.promotions.update(oid, cambios)

    def delete(self, oid: str) -> None:
        self.services.promotions.delete(oid)

    def products(self) -> List[Dict[str, Any]]:
        return self.services.products.list()


__all__ = ["ManagePromotionsController"]
