from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class PromotionFormData:
    producto_id: str
    descuento: int
    inicio: str
    fin: str
    activa: bool = True


__all__ = ["PromotionFormData"]
