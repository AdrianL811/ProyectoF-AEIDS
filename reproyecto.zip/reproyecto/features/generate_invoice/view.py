from __future__ import annotations

from typing import Dict, List

from reproyecto.ui.base_view import FeatureView, ctk, messagebox
from reproyecto.ui.helpers import build_table, populate_table

from .controller import GenerateInvoiceController
from .model import InvoiceLineData


class GenerateInvoiceView(FeatureView):
    def __init__(self, context, controller: GenerateInvoiceController) -> None:
        super().__init__(context)
        self.controller = controller

    def show(self, proveedor: str) -> None:
        window = self.open_window("Generar Factura", "860x600")
        ctk.CTkLabel(window, text=f"Ordenes confirmadas de {proveedor}", font=("Arial", 18)).pack(pady=10)

        columns = ("ID", "Proveedor", "Fecha", "Entrega", "Estado", "Productos")
        tree = build_table(window, columns)

        def load() -> None:
            ordenes = self.controller.pending_orders(proveedor)
            rows = []
            for orden in ordenes:
                productos = ", ".join(
                    [
                        f"{itm.get('nombre', '')} "
                        f"(confirmado {itm.get('cantidad_confirmada') or itm.get('cantidad', 0)})"
                        for itm in orden.get("items", [])
                    ]
                )
                rows.append(
                    [
                        str(orden.get("_id")),
                        orden.get("proveedor_o_cliente", ""),
                        orden.get("fecha", ""),
                        orden.get("fecha_entrega", ""),
                        orden.get("estado", ""),
                        productos,
                    ]
                )
            populate_table(tree, rows)

        def facturar() -> None:
            sel = tree.selection()
            if not sel:
                messagebox.showwarning("Facturas", "Selecciona una orden")
                return
            orden_id = str(tree.item(sel[0])["values"][0])
            orden = self.controller.order_detail(orden_id)
            detalle = ctk.CTkToplevel(window)
            detalle.geometry("420x520")
            detalle.title("Detalle de factura")
            entradas: Dict[str, tuple[dict, ctk.CTkEntry]] = {}
            for item in orden.get("items", []):
                cantidad_facturar = item.get("cantidad_confirmada") or item.get("cantidad", 0)
                linea = ctk.CTkFrame(detalle)
                linea.pack(fill="x", padx=6, pady=4)
                ctk.CTkLabel(
                    linea,
                    text=f"{item.get('nombre', '')} x{cantidad_facturar}",
                ).pack(side="left")
                entry = ctk.CTkEntry(linea)
                entry.insert(0, f"{float(item.get('precio_unit', 0.0)):.2f}")
                entry.pack(side="right")
                entradas[item.get("nombre", str(item.get("producto_id")))] = (
                    {**item, "cantidad_factura": cantidad_facturar},
                    entry,
                )

            def guardar() -> None:
                lineas: List[InvoiceLineData] = []
                for nombre, (info, entry) in entradas.items():
                    try:
                        precio = float(entry.get())
                        if precio < 0:
                            raise ValueError
                    except Exception:
                        messagebox.showerror("Facturas", f"Precio invalido para {nombre}")
                        return
                    lineas.append(
                        InvoiceLineData(
                            producto=nombre,
                            cantidad=info.get("cantidad_factura", 0),
                            precio_unitario=precio,
                        )
                    )
                try:
                    self.controller.create_invoice(orden_id, lineas)
                    messagebox.showinfo("Facturas", "Factura generada")
                    detalle.destroy()
                    load()
                except Exception as err:
                    messagebox.showerror("Facturas", str(err))

            ctk.CTkButton(detalle, text="Guardar factura", command=guardar).pack(pady=12)

        barra = ctk.CTkFrame(window)
        barra.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(barra, text="Generar factura", command=facturar).pack(side="left", padx=6)
        ctk.CTkButton(barra, text="Actualizar", command=load).pack(side="left", padx=6)

        self.bus.subscribe("ordenes:cambio", lambda _=None: load())
        self.bus.subscribe("facturas:cambio", lambda _=None: load())
        load()


__all__ = ["GenerateInvoiceView"]
