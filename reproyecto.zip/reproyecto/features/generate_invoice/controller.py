from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from ..base import FeatureController
from .model import InvoiceLineData


@dataclass
class GenerateInvoiceController(FeatureController):
    """Permite a los proveedores generar facturas de sus ordenes confirmadas."""

    def current_provider(self) -> Optional[str]:
        current = self.services.auth.current_user()
        if not current:
            return None
        return current.get("nombre") or current.get("usuario")

    def pending_orders(self, proveedor: str) -> List[Dict[str, Any]]:
        return self.services.orders.orders_by_provider(
            proveedor,
            estado="confirmada",
            solo_factura_pendiente=True,
        )

    def order_detail(self, orden_id: str) -> Dict[str, Any]:
        return self.services.orders.get(orden_id)

    def create_invoice(self, orden_id: str, lineas: List[InvoiceLineData]) -> str:
        payload = [
            {
                "producto": linea.producto,
                "cantidad": linea.cantidad,
                "precio_unitario": linea.precio_unitario,
            }
            for linea in lineas
        ]
        return self.services.invoices.create(orden_id, payload)


__all__ = ["GenerateInvoiceController"]
