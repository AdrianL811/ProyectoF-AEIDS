"""Paquete principal para la aplicacion de inventario ReProyecto."""

from __future__ import annotations

# Reexportaciones convenientes para quienes utilicen el paquete.

from .config import CONFIG, AppConfig  # noqa: F401
from .event_bus import EventBus  # noqa: F401
from .controller import InventarioController  # noqa: F401
from .views import MainView  # noqa: F401

__all__ = [
    "CONFIG",
    "AppConfig",
    "EventBus",
    "InventarioController",
    "MainView",
]
