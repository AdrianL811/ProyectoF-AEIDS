from __future__ import annotations

import csv
import logging
import os
from datetime import datetime
from typing import Any, List, Protocol

from .gui import GUI_AVAILABLE, filedialog, messagebox

logger = logging.getLogger(__name__)


class ExportStrategy(Protocol):
    """Contrato para estrategias de exportacion tabular."""

    def export(self,
               columns: List[str],
               rows: List[List[Any]],
               suggested_name: str) -> None:
        ...


class ExcelExportStrategy:
    """Exporta los datos a un archivo XLSX utilizando openpyxl."""

    def export(self,
               columns: List[str],
               rows: List[List[Any]],
               suggested_name: str) -> None:
        try:
            from openpyxl import Workbook  # type: ignore
        except Exception as exc:  # pragma: no cover - depende de los paquetes instalados
            if GUI_AVAILABLE and messagebox:
                messagebox.showerror(
                    "Exportacion", f"openpyxl no disponible: {exc}")
            else:
                logger.error("openpyxl no disponible: %s", exc)
            return

        ruta = (
            filedialog.asksaveasfilename(
                initialfile=suggested_name,
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx")],
                title="Guardar reporte",
            )
            if GUI_AVAILABLE and filedialog
            else os.path.abspath(suggested_name)
        )
        if not ruta:
            return

        workbook = Workbook()
        worksheet = workbook.active
        fecha = datetime.now().strftime("%Y-%m-%d")
        worksheet.append([f"Reporte generado el {fecha}"])
        worksheet.append([])
        worksheet.append(columns)
        for row in rows:
            worksheet.append(row)
        workbook.save(ruta)

        if GUI_AVAILABLE and messagebox:
            messagebox.showinfo("Exportacion", f"Archivo guardado:\n{ruta}")
        else:
            logger.info("Archivo XLSX exportado en %s", ruta)


class CSVExportStrategy:
    """Exporta los datos planos a un archivo CSV."""

    def export(self,
               columns: List[str],
               rows: List[List[Any]],
               suggested_name: str) -> None:
        ruta = (
            filedialog.asksaveasfilename(
                initialfile=suggested_name.replace(".xlsx", ".csv"),
                defaultextension=".csv",
                filetypes=[("CSV", "*.csv")],
                title="Guardar CSV",
            )
            if GUI_AVAILABLE and filedialog
            else os.path.abspath(suggested_name.replace(".xlsx", ".csv"))
        )
        if not ruta:
            return

        with open(ruta, "w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(
                [f"Reporte generado el {datetime.now().strftime('%Y-%m-%d')}"])
            writer.writerow([])
            writer.writerow(columns)
            writer.writerows(rows)

        if GUI_AVAILABLE and messagebox:
            messagebox.showinfo("Exportacion", f"CSV guardado:\n{ruta}")
        else:
            logger.info("Archivo CSV exportado en %s", ruta)


__all__ = ["ExportStrategy", "ExcelExportStrategy", "CSVExportStrategy"]
