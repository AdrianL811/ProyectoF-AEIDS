from __future__ import annotations

from typing import Any, Dict, List, Optional

from .event_bus import EventBus
from .features.productos.model import Producto
from .features.promociones.model import Promocion
from .features.proveedores.model import Proveedor
from .features.usuarios.model import Usuario
from .services.container import ServiceContainer


class InventarioController:
    """Fachada de compatibilidad sobre el nuevo contenedor de servicios."""

    def __init__(self, bus: EventBus) -> None:
        self.bus = bus
        self.services = ServiceContainer(bus)
        self.productos = self.services.product_repo
        self.proveedores = self.services.provider_repo
        self.usuarios = self.services.user_repo
        self.promos = self.services.promo_repo
        self.ordenes = self.services.order_repo
        self.facturas = self.services.invoice_repo
        self.hist = self.services.hist_repo
        self.usuario_actual: Optional[Dict[str, Any]] = None

    # ---- auth / usuarios ----
    def login(self, usuario: str, password: str) -> bool:
        ok = self.services.auth.login(usuario, password)
        if ok:
            self.usuario_actual = self.services.session.current_user
        return ok

    def registrar_usuario(self, usuario: Usuario) -> str:
        return self.services.users.create(usuario)

    def actualizar_usuario(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.services.users.update(oid, cambios)

    def eliminar_usuario(self, oid: str) -> None:
        self.services.users.delete(oid)

    # ---- productos ----
    def listar_productos(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.services.products.list(filtros)

    def crear_producto(self, producto: Producto) -> str:
        return self.services.products.create(producto)

    def actualizar_producto(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.services.products.update(oid, cambios)

    def eliminar_producto(self, oid: str) -> None:
        self.services.products.delete(oid)

    # ---- proveedores ----
    def listar_proveedores(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.services.providers.list(filtros)

    def crear_proveedor(self, proveedor: Proveedor) -> str:
        return self.services.providers.create(proveedor)

    def actualizar_proveedor(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.services.providers.update(oid, cambios)

    def eliminar_proveedor(self, oid: str) -> None:
        self.services.providers.delete(oid)

    # ---- recepciones / ajustes ----
    def recepcionar(
        self,
        producto_id: str,
        cantidad: int,
        proveedor_nombre: str,
        caducidad: str,
        estado: str,
    ) -> None:
        usuario = self._current_user_name()
        self.services.stock.reception(
            producto_id,
            cantidad,
            proveedor_nombre,
            caducidad,
            estado,
            usuario,
        )

    def ajustar_stock(self, producto_id: str, delta: int, motivo: str) -> None:
        usuario = self._current_user_name()
        self.services.stock.adjust(producto_id, delta, motivo, usuario)

    # ---- promociones ----
    def listar_promos(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.services.promotions.list(filtros)

    def crear_promo(self, promo: Promocion) -> str:
        return self.services.promotions.create(promo)

    def actualizar_promo(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.services.promotions.update(oid, cambios)

    def eliminar_promo(self, oid: str) -> None:
        self.services.promotions.delete(oid)

    def precio_con_promo(self, producto: Dict[str, Any]) -> float:
        return self.services.promotions.precio_con_promo(producto)

    # ---- ordenes / facturas ----
    def crear_orden(self, proveedor_o_cliente: str, items: List[Dict[str, Any]]) -> str:
        usuario = self._current_user_name()
        order_id, _ = self.services.orders.create_sale_order(proveedor_o_cliente, items, usuario)
        return order_id

    def crear_orden_compra(
        self, proveedor: str, items: List[Dict[str, Any]], fecha_entrega: str
    ) -> str:
        return self.services.orders.create_purchase_order(proveedor, items, fecha_entrega)

    def actualizar_orden(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.services.orders.update(oid, cambios)

    def listar_ordenes(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.services.orders.list(filtros)

    def crear_factura(self, orden_id: str, items_con_precios: List[Dict[str, Any]]) -> str:
        return self.services.invoices.create(orden_id, items_con_precios)

    def listar_facturas(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.services.invoices.list(filtros)

    def ordenes_por_proveedor(
        self, proveedor: str, estado: Optional[str] = None, solo_factura_pendiente: bool = False
    ) -> List[Dict[str, Any]]:
        return self.services.orders.orders_by_provider(proveedor, estado, solo_factura_pendiente)

    # ---- alertas ----
    def alertas(self) -> Dict[str, List[Dict[str, Any]]]:
        return self.services.alerts.current_alerts()

    # ---- utilidades ----
    def _current_user_name(self) -> Optional[str]:
        current = self.services.session.current_user
        self.usuario_actual = current
        if not current:
            return None
        return current.get("nombre") or current.get("usuario")


__all__ = ["InventarioController"]
