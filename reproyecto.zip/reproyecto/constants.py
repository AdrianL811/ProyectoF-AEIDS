from __future__ import annotations

ROLES_DISPONIBLES = ["administrador", "gerente", "encargado", "proveedor"]

SUPPORT_CONTACT = {
    "nombre": "Edgar Espinosa",
    "correo": "edgar.espinosa@lasallistas.org.mx",
    "telefono": "5536977657",
}

__all__ = ["ROLES_DISPONIBLES", "SUPPORT_CONTACT"]
