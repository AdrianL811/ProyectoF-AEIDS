from __future__ import annotations

GUI_AVAILABLE = False

try:
    import tkinter as tk  # type: ignore
    from tkinter import ttk, messagebox, filedialog  # type: ignore
    import customtkinter as ctk  # type: ignore

    GUI_AVAILABLE = True
except Exception:  # pragma: no cover - depende del entorno
    tk = None  # type: ignore
    ttk = None  # type: ignore
    messagebox = None  # type: ignore
    filedialog = None  # type: ignore
    ctk = None  # type: ignore


__all__ = [
    "GUI_AVAILABLE",
    "tk",
    "ttk",
    "messagebox",
    "filedialog",
    "ctk",
]
