from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field

try:
    from dotenv import load_dotenv
except Exception:  # pragma: no cover - fallback solo cuando falta dependencia

    def load_dotenv() -> None:
        return None


load_dotenv()


def _resolve_log_level() -> int:
    level_name = os.getenv("LOG_LEVEL", "INFO").upper()
    return getattr(logging, level_name, logging.INFO)


logging.basicConfig(
    level=_resolve_log_level(),
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

logger = logging.getLogger("reproyecto")


@dataclass(frozen=True)
class AppConfig:
    """Configuracion de la aplicacion obtenida desde el entorno."""

    mongo_uri: str = field(default_factory=lambda: os.getenv(
        "MONGO_URI") or "mongodb://localhost:27017/")
    db_name: str = field(
        default_factory=lambda: os.getenv("DB_NAME") or "supermercado"
    )
    mongo_timeout_raw: str = field(
        default_factory=lambda: os.getenv("MONGO_TIMEOUT_MS") or "2000"
    )

    @property
    def mongo_timeout_ms(self) -> int:
        try:
            return int(self.mongo_timeout_raw)
        except (TypeError, ValueError):
            logger.warning(
                "Invalid MONGO_TIMEOUT_MS value '%s'; falling back to 2000ms",
                self.mongo_timeout_raw,
            )
            return 2000


CONFIG = AppConfig()

__all__ = ["CONFIG", "AppConfig", "logger"]
