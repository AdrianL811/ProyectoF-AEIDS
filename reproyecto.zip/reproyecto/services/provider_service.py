from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

from .base import BaseService
from reproyecto.features.proveedores.model import Proveedor
from reproyecto.repositories import ProveedorRepository


@dataclass
class ProviderService(BaseService):
    """Servicio de administracion de proveedores."""

    proveedores: ProveedorRepository

    def list(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.proveedores.all(filtros or {})

    def get(self, oid: str) -> Dict[str, Any]:
        proveedor = self.proveedores.get(oid)
        if not proveedor:
            raise ValueError("Proveedor no encontrado")
        return proveedor

    def create(self, proveedor: Proveedor) -> str:
        oid = self.proveedores.insert(asdict(proveedor))
        self.emit("proveedores:cambio")
        return oid

    def update(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.proveedores.update(oid, cambios)
        self.emit("proveedores:cambio")

    def delete(self, oid: str) -> None:
        self.proveedores.delete(oid)
        self.emit("proveedores:cambio")


__all__ = ["ProviderService"]
