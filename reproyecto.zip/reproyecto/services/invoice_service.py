from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

from .base import BaseService
from .order_service import OrderService
from reproyecto.repositories import FacturaRepository, OrdenRepository


logger = logging.getLogger(__name__)


@dataclass
class InvoiceService(BaseService):
    """Servicio asociado a la emision y consulta de facturas."""

    facturas: FacturaRepository
    ordenes: OrdenRepository
    orders: OrderService

    def list(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.facturas.all(filtros or {})

    def create(self, orden_id: str, items: List[Dict[str, Any]]) -> str:
        total = 0.0
        detalles: List[Dict[str, Any]] = []
        for item in items:
            cantidad = int(item.get("cantidad", 0))
            precio = float(item.get("precio_unitario", item.get("precio_unit", 0.0)))
            subtotal = round(precio * cantidad, 2)
            total += subtotal
            detalles.append(
                {
                    "producto": item.get("producto")
                    or item.get("nombre")
                    or item.get("producto_nombre", ""),
                    "cantidad": cantidad,
                    "precio_unitario": precio,
                    "subtotal": subtotal,
                }
            )
        payload: Dict[str, Any] = {
            "orden_id": orden_id,
            "productos": detalles,
            "precio_total": round(total, 2),
            "fecha_emision": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        try:
            orden_doc = self.ordenes.get(orden_id)
        except Exception:
            orden_doc = None
        if orden_doc:
            payload["proveedor"] = orden_doc.get("proveedor_o_cliente", "")
            payload["tipo_orden"] = orden_doc.get("tipo", "")

        factura_id = self.facturas.insert(payload)
        try:
            self.orders.update(orden_id, {"facturada": True, "estado": "facturada"})
        except Exception:
            logger.exception(
                "No fue posible actualizar la orden tras generar la factura",
                exc_info=True,
            )
        self.emit("facturas:cambio")
        return factura_id


__all__ = ["InvoiceService"]
