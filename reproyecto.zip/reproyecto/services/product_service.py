from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

from .base import BaseService
from reproyecto.features.productos.model import Producto
from reproyecto.repositories import ProductoRepository


@dataclass
class ProductService(BaseService):
    """Servicio de administracion de productos."""

    productos: ProductoRepository

    def list(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.productos.all(filtros or {})

    def get(self, oid: str) -> Dict[str, Any]:
        producto = self.productos.get(oid)
        if not producto:
            raise ValueError("Producto no encontrado")
        return producto

    def create(self, producto: Producto) -> str:
        oid = self.productos.insert(asdict(producto))
        self.emit("productos:cambio")
        return oid

    def update(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.productos.update(oid, cambios)
        self.emit("productos:cambio")

    def delete(self, oid: str) -> None:
        self.productos.delete(oid)
        self.emit("productos:cambio")


__all__ = ["ProductService"]
