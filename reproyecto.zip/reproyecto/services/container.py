from __future__ import annotations

from dataclasses import dataclass, field

from reproyecto.db import MongoProvider
from reproyecto.event_bus import EventBus
from reproyecto.repositories import (
    FacturaRepository,
    HistorialRepository,
    OrdenRepository,
    ProductoRepository,
    PromocionRepository,
    ProveedorRepository,
    UsuarioRepository,
)

from .alert_service import AlertService
from .auth_service import AuthService
from .invoice_service import InvoiceService
from .order_service import OrderService
from .product_service import ProductService
from .promotion_service import PromotionService
from .provider_service import ProviderService
from .session import SessionState
from .stock_service import StockService
from .user_service import UserService


@dataclass(slots=True)
class ServiceContainer:
    """Contenedor que agrega repositorios y servicios de la aplicacion."""

    bus: EventBus
    product_repo: ProductoRepository = field(init=False)
    provider_repo: ProveedorRepository = field(init=False)
    user_repo: UsuarioRepository = field(init=False)
    promo_repo: PromocionRepository = field(init=False)
    order_repo: OrdenRepository = field(init=False)
    invoice_repo: FacturaRepository = field(init=False)
    hist_repo: HistorialRepository = field(init=False)

    session: SessionState = field(init=False)
    products: ProductService = field(init=False)
    providers: ProviderService = field(init=False)
    users: UserService = field(init=False)
    promotions: PromotionService = field(init=False)
    stock: StockService = field(init=False)
    orders: OrderService = field(init=False)
    invoices: InvoiceService = field(init=False)
    auth: AuthService = field(init=False)
    alerts: AlertService = field(init=False)

    def __post_init__(self) -> None:
        provider = MongoProvider()
        db = provider.db

        self.product_repo = ProductoRepository(db)
        self.provider_repo = ProveedorRepository(db)
        self.user_repo = UsuarioRepository(db)
        self.promo_repo = PromocionRepository(db)
        self.order_repo = OrdenRepository(db)
        self.invoice_repo = FacturaRepository(db)
        self.hist_repo = HistorialRepository(db)

        self.session = SessionState()
        self.products = ProductService(self.bus, self.product_repo)
        self.providers = ProviderService(self.bus, self.provider_repo)
        self.users = UserService(self.bus, self.user_repo)
        self.promotions = PromotionService(self.bus, self.promo_repo)
        self.stock = StockService(self.bus, self.products, self.hist_repo)
        self.orders = OrderService(
            self.bus, self.order_repo, self.products, self.promotions, self.stock
        )
        self.invoices = InvoiceService(self.bus, self.invoice_repo, self.order_repo, self.orders)
        self.auth = AuthService(self.bus, self.user_repo, self.session)
        self.alerts = AlertService(self.bus, self.products)


__all__ = ["ServiceContainer"]
