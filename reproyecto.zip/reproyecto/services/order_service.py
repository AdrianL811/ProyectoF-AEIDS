from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime
from typing import Any, Dict, List, Optional

from .base import BaseService
from .product_service import ProductService
from .promotion_service import PromotionService
from .stock_service import StockService
from reproyecto.features.ordenes.model import Orden, OrdenItem
from reproyecto.repositories import OrdenRepository


@dataclass
class OrderService(BaseService):
    """Gestion integrada de ordenes de venta y compra."""

    ordenes: OrdenRepository
    productos: ProductService
    promos: PromotionService
    stock: StockService

    def list(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.ordenes.all(filtros or {})

    def get(self, oid: str) -> Dict[str, Any]:
        orden = self.ordenes.get(oid)
        if not orden:
            raise ValueError("Orden no encontrada")
        return orden

    def create_sale_order(
        self, proveedor_o_cliente: str, items: List[Dict[str, Any]], usuario: Optional[str]
    ) -> tuple[str, List[Dict[str, Any]]]:
        detalle: List[OrdenItem] = []
        total = 0.0
        for item in items:
            producto = self.productos.get(item["producto_id"])
            cantidad = int(item["cantidad"])
            if cantidad <= 0:
                raise ValueError("Cantidad invalida")
            precio_final = self.promos.precio_con_promo(producto)
            total += precio_final * cantidad
            detalle.append(
                OrdenItem(
                    producto_id=str(producto.get("_id")),
                    nombre=producto.get("nombre", ""),
                    cantidad=cantidad,
                    precio_unit=precio_final,
                )
            )
        for item in items:
            self.stock.adjust(
                item["producto_id"],
                -int(item["cantidad"]),
                "venta/orden",
                usuario,
            )
        orden = Orden(
            proveedor_o_cliente=proveedor_o_cliente,
            fecha=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            items=detalle,
            total=round(total, 2),
            tipo="venta",
            estado="completada",
            facturada=False,
        )
        payload = asdict(orden)
        oid = self.ordenes.insert(payload)
        self.emit("ordenes:cambio")
        invoice_items = [
            {
                "producto": item.nombre,
                "cantidad": item.cantidad,
                "precio_unitario": item.precio_unit,
            }
            for item in detalle
        ]
        return oid, invoice_items

    def create_purchase_order(
        self, proveedor: str, items: List[Dict[str, Any]], fecha_entrega: str
    ) -> str:
        if not proveedor:
            raise ValueError("Proveedor requerido")
        if not items:
            raise ValueError("Selecciona al menos un producto")
        detalle: List[OrdenItem] = []
        for item in items:
            producto = self.productos.get(item["producto_id"])
            cantidad = int(item.get("cantidad", 0))
            if cantidad <= 0:
                raise ValueError("Cantidad invalida")
            detalle.append(
                OrdenItem(
                    producto_id=str(producto.get("_id")),
                    nombre=producto.get("nombre", ""),
                    cantidad=cantidad,
                    precio_unit=0.0,
                )
            )
        orden = Orden(
            proveedor_o_cliente=proveedor,
            fecha=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            items=detalle,
            total=0.0,
            tipo="compra",
            estado="pendiente",
            fecha_entrega=fecha_entrega or "",
            facturada=False,
        )
        payload = asdict(orden)
        oid = self.ordenes.insert(payload)
        self.emit("ordenes:cambio")
        return oid

    def confirm_purchase_order(
        self,
        oid: str,
        items: List[Dict[str, Any]],
        fecha_entrega: Optional[str] = None,
        nota: str = "",
    ) -> None:
        if not items:
            raise ValueError("Proporciona al menos un producto a confirmar")

        orden = self.get(oid)
        if orden.get("tipo") != "compra":
            raise ValueError("Solo se pueden confirmar ordenes de compra")

        current_items = orden.get("items", [])
        indexed = {str(item.get("producto_id")): item for item in current_items}
        prepared: Dict[str, Dict[str, Any]] = {}
        total = 0.0

        for payload in items:
            producto_id = str(payload.get("producto_id", "")).strip()
            if not producto_id:
                raise ValueError("Id de producto invalido")

            base = indexed.pop(producto_id, None)
            if base is None:
                producto = self.productos.get(producto_id)
                base = {
                    "producto_id": producto_id,
                    "nombre": producto.get("nombre", ""),
                    "cantidad": int(payload.get("cantidad_confirmada", 0)),
                    "precio_unit": 0.0,
                    "descuento": 0,
                }

            base = base.copy()
            confirm_qty = int(payload.get("cantidad_confirmada", base.get("cantidad", 0)))
            if confirm_qty <= 0:
                raise ValueError("Cantidad confirmada invalida")
            price = float(payload.get("precio_unit", base.get("precio_unit", 0.0)))
            if price < 0:
                raise ValueError("Precio invalido")

            base["cantidad_confirmada"] = confirm_qty
            base["precio_unit"] = price
            prepared[producto_id] = base

        # mantener los elementos no confirmados con sus valores previos y respetar el orden original
        updated: List[Dict[str, Any]] = []
        for item in current_items:
            producto_id = str(item.get("producto_id"))
            if producto_id in prepared:
                updated.append(prepared.pop(producto_id))
            else:
                updated.append(item)

        # agregar nuevos elementos confirmados que no estaban en la orden original
        updated.extend(prepared.values())

        total = 0.0
        for item in updated:
            qty = int(item.get("cantidad_confirmada") or item.get("cantidad", 0))
            price = float(item.get("precio_unit", 0.0))
            total += price * qty

        cambios: Dict[str, Any] = {
            "items": updated,
            "total": round(total, 2),
            "estado": "confirmada",
        }
        if fecha_entrega is not None and fecha_entrega.strip():
            cambios["fecha_entrega"] = fecha_entrega.strip()
        if nota.strip():
            cambios["nota_proveedor"] = nota.strip()

        self.update(oid, cambios)

    def update(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.ordenes.update(oid, cambios)
        self.emit("ordenes:cambio")

    def orders_by_provider(
        self, proveedor: str, estado: Optional[str] = None, solo_factura_pendiente: bool = False
    ) -> List[Dict[str, Any]]:
        filtros: Dict[str, Any] = {"tipo": "compra", "proveedor_o_cliente": proveedor}
        if estado:
            filtros["estado"] = estado
        if solo_factura_pendiente:
            filtros["facturada"] = False
        return self.list(filtros)


__all__ = ["OrderService"]
