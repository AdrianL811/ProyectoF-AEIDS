from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .base import BaseService
from .product_service import ProductService
from reproyecto.repositories import HistorialRepository


@dataclass
class StockService(BaseService):
    """Operaciones que modifican el stock y registran historial."""

    productos: ProductService
    historial: HistorialRepository

    def reception(
        self,
        producto_id: str,
        cantidad: int,
        proveedor_nombre: str,
        caducidad: str,
        estado: str,
        usuario: Optional[str],
    ) -> None:
        producto = self.productos.get(producto_id)
        cantidad_actual = int(producto.get("cantidad", 0))
        nuevo_total = cantidad_actual + int(cantidad)
        if nuevo_total < 0:
            raise ValueError("El stock no puede ser negativo")
        self.productos.update(
            producto_id,
            {"cantidad": nuevo_total, "proveedor": proveedor_nombre},
        )
        usuario_label = usuario or "sistema"
        self.historial.log_cambio(
            producto_id,
            producto.get("nombre", ""),
            cantidad_actual,
            nuevo_total,
            usuario_label,
        )
        self.historial.log_recepcion(
            producto_id,
            producto.get("nombre", ""),
            proveedor_nombre,
            int(cantidad),
            caducidad,
            estado,
        )
        self.historial.log_ajuste(
            producto_id,
            producto.get("nombre", ""),
            "entrada",
            int(cantidad),
            "recepcion",
        )

    def adjust(self, producto_id: str, delta: int, motivo: str, usuario: Optional[str]) -> None:
        producto = self.productos.get(producto_id)
        cantidad_actual = int(producto.get("cantidad", 0))
        nuevo_total = cantidad_actual + int(delta)
        if nuevo_total < 0:
            raise ValueError("El stock no puede ser negativo")
        self.productos.update(producto_id, {"cantidad": nuevo_total})
        usuario_label = usuario or "sistema"
        self.historial.log_cambio(
            producto_id,
            producto.get("nombre", ""),
            cantidad_actual,
            nuevo_total,
            usuario_label,
        )
        self.historial.log_ajuste(
            producto_id,
            producto.get("nombre", ""),
            "entrada" if delta >= 0 else "salida",
            abs(int(delta)),
            motivo,
        )


__all__ = ["StockService"]
