from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from .base import BaseService
from .session import SessionState
from reproyecto.repositories import UsuarioRepository


@dataclass
class AuthService(BaseService):
    """Autenticacion de usuarios y gestion de sesion."""

    usuarios: UsuarioRepository
    session: SessionState

    def login(self, usuario: str, password: str) -> bool:
        doc = self.usuarios.get_by_user(usuario)
        if doc and doc.get("password") == password:
            self.session.login(doc)
            self.emit("auth:login", {"usuario": doc})
            return True
        return False

    def logout(self) -> None:
        self.session.logout()
        self.emit("auth:logout")

    def current_user(self) -> Optional[dict]:
        return self.session.current_user


__all__ = ["AuthService"]
