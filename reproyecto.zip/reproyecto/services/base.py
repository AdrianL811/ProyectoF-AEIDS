from __future__ import annotations

from dataclasses import dataclass

from reproyecto.event_bus import EventBus


@dataclass
class BaseService:
    """Servicio base que proporciona acceso al bus de eventos."""

    bus: EventBus

    def emit(self, channel: str, payload=None) -> None:
        """Propaga un mensaje en el bus central."""
        self.bus.emit(channel, payload or {})


__all__ = ["BaseService"]
