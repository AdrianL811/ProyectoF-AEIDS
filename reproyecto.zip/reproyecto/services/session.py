from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass(slots=True)
class SessionState:
    """Gestion sencilla de la sesion activa en la aplicacion."""

    current_user: Optional[Dict[str, Any]] = field(default=None)

    def login(self, user_doc: Dict[str, Any]) -> None:
        self.current_user = user_doc

    def logout(self) -> None:
        self.current_user = None


__all__ = ["SessionState"]
