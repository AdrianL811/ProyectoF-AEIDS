from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Dict, List

from .base import BaseService
from .product_service import ProductService


@dataclass
class AlertService(BaseService):
    """Detecta alertas operativas vinculadas a productos."""

    productos: ProductService

    def current_alerts(self) -> Dict[str, List[Dict[str, object]]]:
        resultado: Dict[str, List[Dict[str, object]]] = {"stock_bajo": [], "proxima_caducidad": []}
        hoy = date.today()
        limite = hoy + timedelta(days=15)
        for producto in self.productos.list():
            if int(producto.get("cantidad", 0)) < 10:
                resultado["stock_bajo"].append(producto)
            caducidad = producto.get("fecha_caducidad")
            if caducidad:
                try:
                    fecha_caducidad = datetime.strptime(caducidad, "%Y-%m-%d").date()
                    if hoy <= fecha_caducidad <= limite:
                        resultado["proxima_caducidad"].append(producto)
                except Exception:
                    continue
        return resultado


__all__ = ["AlertService"]
