from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional

from .base import BaseService
from reproyecto.features.usuarios.model import Usuario
from reproyecto.repositories import UsuarioRepository


@dataclass
class UserService(BaseService):
    """Servicio de gestion de usuarios del sistema."""

    usuarios: UsuarioRepository

    def list(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.usuarios.all(filtros or {})

    def create(self, usuario: Usuario) -> str:
        oid = self.usuarios.insert(asdict(usuario))
        self.emit("usuarios:cambio")
        return oid

    def get_by_username(self, username: str) -> Optional[Dict[str, Any]]:
        return self.usuarios.get_by_user(username)

    def get(self, oid: str) -> Dict[str, Any]:
        usuario = self.usuarios.get(oid)
        if not usuario:
            raise ValueError("Usuario no encontrado")
        return usuario

    def update(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.usuarios.update(oid, cambios)
        self.emit("usuarios:cambio")

    def delete(self, oid: str) -> None:
        self.usuarios.delete(oid)
        self.emit("usuarios:cambio")


__all__ = ["UserService"]
