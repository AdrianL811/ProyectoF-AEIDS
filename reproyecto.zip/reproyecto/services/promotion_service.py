from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import date, datetime
from typing import Any, Dict, List, Optional

from .base import BaseService
from reproyecto.features.promociones.model import Promocion
from reproyecto.repositories import PromocionRepository


@dataclass
class PromotionService(BaseService):
    """Gestion de promociones aplicadas a productos."""

    promociones: PromocionRepository

    def list(self, filtros: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        return self.promociones.all(filtros or {})

    def create(self, promo: Promocion) -> str:
        oid = self.promociones.insert(asdict(promo))
        self.emit("promos:cambio")
        return oid

    def update(self, oid: str, cambios: Dict[str, Any]) -> None:
        self.promociones.update(oid, cambios)
        self.emit("promos:cambio")

    def delete(self, oid: str) -> None:
        self.promociones.delete(oid)
        self.emit("promos:cambio")

    def precio_con_promo(self, producto: Dict[str, Any]) -> float:
        base = float(producto.get("precio", 0.0))
        hoy = date.today()
        for promo in self.list():
            if not promo.get("activa", True):
                continue
            if str(promo.get("producto_id")) != str(producto.get("_id")):
                continue
            try:
                inicio = datetime.strptime(promo.get("inicio"), "%Y-%m-%d").date()
                fin = datetime.strptime(promo.get("fin"), "%Y-%m-%d").date()
                if inicio <= hoy <= fin:
                    descuento = int(promo.get("descuento", 0))
                    return round(base * (1 - descuento / 100.0), 2)
            except Exception:
                continue
        return base


__all__ = ["PromotionService"]
